﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using StringSearcher.Model;
using StringSearcher.Controller;
using System.IO;
using System.Drawing;

namespace StringSearcher
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDBAdd_Click(object sender, EventArgs e)
        {
            if (txtDBList.Text.Trim() != "")
            {
                lbDBName.Items.Add(txtDBList.Text);
                txtDBList.Text = "";
            }
        }

        protected void btnDBReset_Click(object sender, EventArgs e)
        {
            lbDBName.Items.Clear();
        }

        protected void btnAddAppFolName_Click(object sender, EventArgs e)
        {
            if (txtAppFolName.Text.Trim() != "" && txtAppName.Text.Trim() != "")
            {
                lstAppFolder.Items.Add(txtAppFolName.Text);
                lstAppName.Items.Add(txtAppName.Text);
                txtAppFolName.Text = "";
                txtAppName.Text = "";
            }
        }

        protected void btnAppFolReset_Click(object sender, EventArgs e)
        {
            lstAppFolder.Items.Clear();
            lstAppName.Items.Clear();
        }

        protected void btnStart_Click(object sender, EventArgs e)
        {
            txtAppFolFileSearchResult.Text = "";
            txtDBSearchResult.Text = "";
            btnStart.Enabled = false;
            btnExcelDownload.Enabled = false;
            StringBuilder sb = new StringBuilder();
            lblValidation.Text = "";
            if (txtStringSearch.Text.Trim() == "") sb.Append("*Fill Search String." + Environment.NewLine);
            if (txtServerIP.Text.Trim() == "") sb.Append("*Fill Server IP Details." + Environment.NewLine);
            if (lbDBName.Items.Count == 0) sb.Append("*Fill DB List." + Environment.NewLine);
            if (lstAppFolder.Items.Count == 0) sb.Append("*Fill Application Folder." + Environment.NewLine);
            if (lstAppName.Items.Count == 0) sb.Append("*Fill Application Name" + Environment.NewLine);
            if (sb.Length > 0) { 
                lblValidation.Text = sb.ToString();
                lblValidation.ForeColor = Color.Red;
                btnStart.Enabled = true;
                btnExcelDownload.Enabled = true;
                return; 
            };

            lblValidation.Text = "String Search In Progress.......";
            lblValidation.ForeColor = Color.OrangeRed;
            SearchItems objSI = new SearchItems();
            objSI.S_SEARCH_STRING = txtStringSearch.Text;
            objSI.S_SEARCH_IP = txtServerIP.Text;
            for (int i = 0; i < lbDBName.Items.Count; i++)
                objSI.S_DB_LIST.Add(lbDBName.Items[i].ToString());

            for (int i = 0; i < lstAppFolder.Items.Count; i++)
                objSI.S_APP_FOLDER_LIST.Add(lstAppFolder.Items[i].ToString());

            for (int i = 0; i < lstAppName.Items.Count; i++)
                objSI.S_APP_NAME_LIST.Add(lstAppName.Items[i].ToString());
            //objSI.S_DB_LIST = lbDBName.Items.OfType<string>().ToList();
            //objSI.S_APP_FOLDER_LIST = lstAppFolder.Items.OfType<string>().ToList();
            SearchStart(objSI);
            btnStart.Enabled = true;
            btnExcelDownload.Enabled = true;
            lblValidation.Text = "String Search Completed";
            lblValidation.ForeColor = Color.DarkSeaGreen;
        }
       static List<SearchStringResult> objED = new List<SearchStringResult>();
        public void SearchStart(SearchItems objSI)
        {            
            List<SPList> objSPList = new List<SPList>();
            List<SPList> objSPListFinal = new List<SPList>();
            SearchController objSC = new SearchController();
            for (int dbListCount = 0; dbListCount < objSI.S_DB_LIST.Count; dbListCount++)
            {
                objSPList = objSC.objSearchDB(objSI.S_SEARCH_IP, objSI.S_DB_LIST[dbListCount], objSI.S_SEARCH_STRING).Cast<SPList>().ToList();
                objSPListFinal.AddRange(objSPList);
            }

            txtDBSearchResult.Text = string.Join(Environment.NewLine, objSPListFinal.Select(x => string.Format("Type:{0},Name:{1},DB Name:{2},Parent:{3}", x.S_TYPE, x.S_SP_NAME, x.S_DB_NAME, x.S_SP_PARENT)));

            List<AppFolderList> fileList = new List<AppFolderList>();
            for (int fldCount = 0; fldCount < objSI.S_APP_FOLDER_LIST.Count; fldCount++)
            {
                foreach (string file in Directory.EnumerateFiles(objSI.S_APP_FOLDER_LIST[fldCount], "*.*", SearchOption.AllDirectories).Where(s => s.EndsWith(".cs") || s.EndsWith(".aspx.cs") || s.EndsWith(".xml")))
                //foreach (string file in Directory.EnumerateFiles(objSI.S_APP_FOLDER_LIST[fldCount], "*.*", SearchOption.AllDirectories).Where(s => s.EndsWith(".xml")))
                {
                    fileList.Add(new AppFolderList { S_APP_NAME = objSI.S_APP_NAME_LIST[fldCount], S_FOLDER_PATH = file });
                }
            }

            StringBuilder objAppFinalResult = new StringBuilder();
            objED = new List<SearchStringResult>();
            bool isFileFind = false;
            string strAppName = "";
            foreach (SPList spName in objSPListFinal)
            {
                isFileFind = false;
                foreach (AppFolderList filePath in fileList)
                {
                    try
                    {
                        foreach (string line in System.IO.File.ReadAllLines(filePath.S_FOLDER_PATH))
                        {
                            if (line.IndexOf("\""+spName.S_SP_NAME+"\"") > 0)
                            {
                                objAppFinalResult.Append(string.Format("Type:{0},Name: {1},DB Name:{2},Parent: {3},File Path:{4},App Name:{5},{6}", spName.S_TYPE, spName.S_SP_NAME, spName.S_DB_NAME, spName.S_SP_PARENT, filePath.S_FOLDER_PATH, filePath.S_APP_NAME, Environment.NewLine));
                                objED.Add(new SearchStringResult { APP_NAME = filePath.S_APP_NAME, DB_NAME = spName.S_DB_NAME, IS_RECURSIVE_SP = spName.S_IS_RECURSIVE, SP_NAME = spName.S_SP_NAME, SP_PARENT = spName.S_SP_PARENT, TYPE = spName.S_TYPE, FILE_PATH = filePath.S_FOLDER_PATH });
                                isFileFind = true;

                            }
                            strAppName = filePath.S_APP_NAME;
                        }
                    }
                    catch { }
                }
                if (!isFileFind)
                {
                    objED.Add(new SearchStringResult { FILE_PATH = "", APP_NAME = strAppName, DB_NAME = spName.S_DB_NAME, IS_RECURSIVE_SP = spName.S_IS_RECURSIVE, SP_NAME = spName.S_SP_NAME, SP_PARENT = spName.S_SP_PARENT, TYPE = spName.S_TYPE });
                    isFileFind = false;
                }

            }

            txtAppFolFileSearchResult.Text = objAppFinalResult.ToString();
        }

        protected void btnExcelDownload_Click(object sender, EventArgs e)
        {
            SearchController.DownloadExcel(objED.Distinct().ToList());
        }
    }

}