﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StringSearcher.Model
{
    public class SearchItems
    {
        public string S_SEARCH_STRING { get; set; }
        public string S_SEARCH_IP { get; set; }
        public List<string> S_DB_LIST = new List<string>();
        public List<string> S_APP_FOLDER_LIST = new List<string>();
        public List<string> S_APP_NAME_LIST = new List<string>();
    }

    public class SPList
    {
        public string S_TYPE { get; set; }
        public string S_DB_NAME { get; set; }
        public string S_SP_NAME { get; set; }
        public string S_SP_PARENT { get; set; }
        public string S_IS_RECURSIVE { get; set; }
    }

    public class AppFolderList
    {
        public string S_FOLDER_PATH { get; set; }
        public string S_APP_NAME { get; set; }
    }

    public class SearchStringResult
    {
        public string APP_NAME { get; set; }
        public string TYPE { get; set; }
        public string SP_NAME { get; set; }
        public string DB_NAME { get; set; }
        public string SP_PARENT { get; set; }
        public string IS_RECURSIVE_SP { get; set; }
        public string FILE_PATH { get; set; }
    }
 
}