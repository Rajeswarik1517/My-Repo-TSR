﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;


namespace StringSearcher.Model
{
    public class DBConnection
    {        
        public static IDbConnection objSqlConnect(string serverName,string dbName)
        {
           return new SqlConnection("Data Source="+serverName+";Initial Catalog="+dbName+";Integrated Security=SSPI;Connection Timeout=0");
        }

        public static string SEARCHSP()
        {
            return @"
                IF object_id('SplitString', 'TF') IS NOT NULL
                BEGIN
                    DROP FUNCTION [dbo].[SplitString]
                END
                GO
                CREATE  
                FUNCTION [dbo].[SplitString](@String nvarchar(MAX), @Delimiter char(1))   
                RETURNS  
                @Results TABLE (String varchar(255))   
                AS  
                BEGIN   
                DECLARE @INDEX INT   
                DECLARE @SLICE nvarchar(MAX)   
                -- HAVE TO SET TO 1 SO IT DOESNT EQUAL Z   
                -- ERO FIRST TIME IN LOOP   
                SELECT @INDEX = 1   
                WHILE @INDEX !=0   
                BEGIN   
                -- GET THE INDEX OF THE FIRST OCCURENCE OF THE SPLIT CHARACTER   
                SELECT @INDEX = CHARINDEX(@Delimiter,@STRING)   
                -- NOW PUSH EVERYTHING TO THE LEFT OF IT INTO THE SLICE VARIABLE   
                IF @INDEX !=0   
                SELECT @SLICE = LEFT(@STRING,@INDEX - 1)   
                ELSE   
                SELECT @SLICE = @STRING   
                -- PUT THE ITEM INTO THE RESULTS SET if it is a number   
                INSERT INTO @Results(String) VALUES(LTRIM(RTRIM(@SLICE)))   
                -- CHOP THE ITEM REMOVED OFF THE MAIN STRING   
                SELECT @STRING = RIGHT(@STRING,LEN(@STRING) - @INDEX)   
                -- BREAK OUT IF WE ARE DONE   
                IF LEN(@STRING) = 0 BREAK   
                END   
                RETURN   
                END  
                  
                GO
                IF OBJECT_ID('spsSearchCode', 'P') IS NOT NULL
                    DROP PROCEDURE spsSearchCode
                GO
                CREATE PROCEDURE [dbo].[spsSearchCode] 
                (
                @Strings 
                AS VARCHAR (255) 
                )
                AS
                BEGIN
                SET
                NOCOUNT ON 
                SET
                TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 
                 
                DECLARE @tmpString TABLE 
                ( 
                RowNum 
                int NOT NULL IDENTITY (1, 1) 
                , String varchar(2000) 
                ) 
                DECLARE @tmp TABLE 
                ( 
                RowNum 
                int 
                , objType varchar(50) 
                , objSeq int 
                , objName varchar(255) 
                , objParentName varchar(255) 
                ) 
                insert into 
                @tmpString
                ( 
                String
                ) 
                select 
                String
                from 
                dbo.SplitString(@Strings, ',') 
                DECLARE @StringCount int 
                SELECT @StringCount = MAX(RowNum) FROM @tmpString 
                DECLARE @RowNum int 
                DECLARE @String varchar(255) 
                DECLARE curString CURSOR FOR 
                SELECT 
                RowNum
                , String 
                FROM 
                @tmpString
                OPEN curString 
                FETCH NEXT FROM curString INTO @RowNum, @String 
                WHILE @@FETCH_STATUS = 0 
                BEGIN 
                 
                insert into 
                @tmp
                select distinct 
                @RowNum
                , 
                CASE sysobjects.type 
                when 'P' THEN 'Stored Proc' 
                when 'V' THEN 'View' 
                when 'FN' THEN 'Function' 
                when 'TF' THEN 'Function' 
                when 'TR' THEN 'Trigger' 
                END AS objType, 
                CASE sysobjects.type 
                when 'P' THEN 1 
                when 'V' THEN 2 
                when 'FN' THEN 3 
                WHEN 'TF' THEN 3 
                when 'TR' THEN 4 
                END AS objSeq, 
                sysobjects
                .Name as objName, 
                NULL as objParentName 
                from 
                sysobjects 
                (nolock) 
                inner join syscomments (nolock) on syscomments.ID = sysobjects.ID 
                where 
                sysobjects
                .type in ('P', 'V', 'FN', 'TR', 'TF') -- stored procs, views, functions, triggers 
                and (syscomments.text like '%' + @String + '%') 
                -- jobs 
                insert into 
                @tmp
                select 
                @RowNum
                , 'Job' As objType 
                , 5 as objSeq 
                , 'Step ' + cast(js.step_id as varchar(5)) + ': ' + js.step_name as objName 
                , j.name + ' ' + case when j.enabled = 1 then '(Enabled)' else '(Disabled)' end as objParentName 
                from 
                msdb
                ..sysjobsteps js (nolock) 
                inner join msdb..sysjobs j (nolock) on js.job_id = j.job_id 
                where 
                js
                .command like '%' + @String + '%' 
                -- table names 
                insert into 
                @tmp
                select 
                @RowNum
                , 'Table' as objType 
                , 6 as objSeq 
                , syscolumns.name as objName 
                , sysobjects.name as objParentName 
                from 
                syscolumns 
                (nolock) 
                inner join sysobjects (nolock) on syscolumns.id = sysobjects.id 
                where 
                syscolumns
                .name like '%' + @String + '%' 
                and sysobjects.type = 'U' 
                FETCH NEXT FROM curString INTO @RowNum, @String 
                END 
                CLOSE curString 
                DEALLOCATE curString 
                delete from 
                @tmp
                where 
                (objName like '%_tmp%' or objName like '%tmp_%' or objName like '%_bak%' or objName like '%bak_%' or objName like '%_tommy%' or objName like '%tommy_%') 
                select 
                t1
                .objType as Type 
                , t1.objName as Object 
                , t1.objParentName as Parent 
                from 
                @tmp t1
                INNER JOIN 
                ( 
                SELECT 
                objType
                , objName 
                , objParentName 
                FROM 
                @tmp
                GROUP BY 
                objType
                , objName 
                , objParentName 
                HAVING 
                COUNT(*) = @StringCount 
                ) as t2 ON t1.objType = t2.objType and t1.objName = t2.ObjName and coalesce(t1.objParentName, '') = coalesce(t2.objParentName, '') 
                group by 
                t1
                .objType 
                , t1.objName 
                , t1.objParentName 
                order by 
                MIN(t1.objSeq) 
                , t1.objType 
                , t1.objName 
                , t1.objParentName 
                END              
                GO

                    IF OBJECT_ID('USP_RECURSIVE_SP_SEARCH', 'P') IS NOT NULL
                        DROP PROCEDURE USP_RECURSIVE_SP_SEARCH
                    GO
                    --USP_RECURSIVE_SP_SEARCH 'PA_PS_FIN_ID%VM_PA_PROJECT'
                    CREATE PROCEDURE USP_RECURSIVE_SP_SEARCH (@SEARCH_STRING VARCHAR(MAX))
                    AS
                    BEGIN
                    DECLARE @COUNT INT=1,@LOOP_COUNT INT,@S_SP_NAME VARCHAR(MAX)
                    
                    CREATE TABLE #TEMP_SPLIST(SNO INT IDENTITY(1,1),S_TYPE VARCHAR(255),S_SP_NAME VARCHAR(MAX),S_SP_PARENT VARCHAR(MAX), IS_CHECKED BIT DEFAULT 0)
                    CREATE TABLE #TEMP_SPLIST_TEMP(S_TYPE VARCHAR(255),S_SP_NAME VARCHAR(MAX),S_SP_PARENT VARCHAR(MAX))
                    --SELECT * FROM #TEMP_SPLIST
                    
                    INSERT INTO #TEMP_SPLIST(S_TYPE,S_SP_NAME,S_SP_PARENT)
                    EXEC SPSSEARCHCODE @SEARCH_STRING
                    
                    UPDATE #TEMP_SPLIST SET S_SP_PARENT=@SEARCH_STRING WHERE S_SP_PARENT IS NULL
                    --SELECT * FROM #TEMP_SPLIST
                    
                    SELECT @LOOP_COUNT=MAX(SNO) FROM #TEMP_SPLIST
                    
                    WHILE(@COUNT<=@LOOP_COUNT)
                    		BEGIN
                    		  SELECT @S_SP_NAME=S_SP_NAME FROM #TEMP_SPLIST WHERE SNO=@COUNT AND IS_CHECKED=0
                    		  IF(@S_SP_NAME<>'')
                    		  BEGIN
                    			INSERT INTO #TEMP_SPLIST_TEMP(S_TYPE,S_SP_NAME,S_SP_PARENT)
                    			EXEC SPSSEARCHCODE @S_SP_NAME
                    
                    			DELETE A FROM #TEMP_SPLIST_TEMP A JOIN #TEMP_SPLIST B ON A.S_TYPE=B.S_TYPE AND A.S_SP_NAME=B.S_SP_NAME
                    
                    			INSERT INTO #TEMP_SPLIST(S_TYPE,S_SP_NAME,S_SP_PARENT)
                    			SELECT S_TYPE,S_SP_NAME,S_SP_PARENT FROM #TEMP_SPLIST_TEMP
                    
                    			UPDATE #TEMP_SPLIST SET S_SP_PARENT=@S_SP_NAME WHERE S_SP_PARENT IS NULL
                    			UPDATE #TEMP_SPLIST SET IS_CHECKED=1 WHERE SNO=@COUNT
                    		  END
                    		  SET @COUNT=@COUNT+1;
                    		  SELECT @LOOP_COUNT=MAX(SNO) FROM #TEMP_SPLIST
                    		END
                    		SELECT S_TYPE,S_DB_NAME=DB_NAME(),S_SP_NAME,S_SP_PARENT FROM #TEMP_SPLIST
                    END
                
                
                ";
        }
    }
}