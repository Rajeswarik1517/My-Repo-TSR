USE [HCM92DEV]
GO
-- sp_helptext 'USP_PS_CITIZEN_PSSPRT_SYNC'

  
-- select * from ORA_CITIZEN_PSSPRT_XML_SYNC WHERE DID='823236'  
-- UPDATE ORA_CITIZEN_PSSPRT_XML_SYNC SET PROCESS_FLAG=0   
-- select * from PS_CITIZEN_PSSPRT_STG  
-- TRUNCATE TABLE PS_CITIZEN_PSSPRT_STG  
  
--SELECT LEN(EXTRACT_XML),DID FROM ORA_CITIZEN_PSSPRT_XML_SYNC  
  
--select  * from PS_CITIZEN_PSSPRT_STG WHERE EMPLID='00000'  
--select * from PS_CITIZEN_PSSPRT WHERE EMPLID='00000' COMMENTS='FUSION'  
  
-- update PS_CITIZEN_PSSPRT set DT_ISSUED=NULL where EMPLID='00000'  
  
--  EXEC USP_PS_CITIZEN_PSSPRT_SYNC  
  
ALTER PROCEDURE [dbo].[USP_PS_CITIZEN_PSSPRT_SYNC]   
AS  
BEGIN  
  
 DECLARE @DocumentId INT  
 DECLARE @DDOCNAME Varchar(400)  
   
 DECLARE @docHandle int;    
 DECLARE @xmlDocument nvarchar(max); -- or xml type    
   
 DECLARE @StrRaiseError VARCHAR(100);  
  
 DECLARE @RECCNT  INT  
 DECLARE @EMPLID Varchar(11)  
 DECLARE @PASSPORT_NBR VARCHAR(30),@DEPENDENT_ID VARCHAR(30),@COUNTRY VARCHAR(30)  
  
 DECLARE @DID INT  
   
-- PART A - XML Sync to Staging Table  
   
DECLARE @tblxml TABLE    
 (    
   U_ID INT IDENTITY(1,1)     
  , DID BIGINT    
  , ENTITYNAME VARCHAR(50)    
  , EXTRACT_XML nvarchar(max)    
  , DDOCNAME VARCHAR(50)    
  )   
  DECLARE @TotalFiles INT   
     
  SELECT @TotalFiles = COUNT(1) FROM ORA_CITIZEN_PSSPRT_XML_SYNC WHERE PROCESS_FLAG = 0    
  INSERT INTO @tblxml (DID, ENTITYNAME, EXTRACT_XML, DDOCNAME)     
  SELECT   DISTINCT  
   DID, ENTITYNAME, EXTRACT_XML, DDOCNAME FROM ORA_CITIZEN_PSSPRT_XML_SYNC     
  WHERE     
   PROCESS_FLAG = 0    
   AND DID NOT IN (SELECT DID FROM PS_HX_EMPL_TSR_TBL_STG)    
   ORDER BY DID  
  
  DECLARE @i INT=1      
       
--SELECT '@tblxml',* FROM @tblxml  
     
 SET @StrRaiseError= 'Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_files to be procssed: ' + RTRIM(CAST(@TotalFiles AS varchar(10)));  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   
 WHILE @i<=@TotalFiles  --Main Loop  
  BEGIN   
   --SET @DDOCNAME=(SELECT DDOCNAME from ##CITIZEN_PSSPRT_SYNC_A WHERE TABLEID=@i)  
   --SET @DID= (SELECT DID from ##CITIZEN_PSSPRT_SYNC_A WHERE TABLEID=@i)  
     
   SET @StrRaiseError= 'Processing file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   --SET @XmlDocument=(SELECT EXTRACT_XML FROM ORA_CITIZEN_PSSPRT_XML_SYNC WHERE DDOCNAME=@DDOCNAME AND PROCESS_FLAG=0)  
    SELECT @XmlDocument = EXTRACT_XML  
    , @DDOCNAME = DDOCNAME  
    , @DID = DID   
    from @tblxml WHERE U_ID = @i   
     
   EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDocument;   
     
   SET @StrRaiseError= 'Xml prepare and parsing process completed for the file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   IF @XmlDocument <>''   
      
    SET @StrRaiseError= 'Xml to Staging table for the file ... '+ @DDOCNAME  
    RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
--TRUNCATE TABLE PS_CITIZEN_PSSPRT_STG  
    BEGIN   
     INSERT INTO PS_CITIZEN_PSSPRT_STG (  
       EMPLID,PersonId,DEPENDENT_ID,COUNTRY,PASSPORT_NBR,DT_ISSUED,  
       --HEX_ACTIVE_PSPT,  
       EXPIRATN_DT,COUNTRY_PASSPORT,  
       STATE_PASSPORT,  
       CITY_PASSPORT,ISSUING_AUTHORITY ,PASSPORT_ID,  
        PROCESS_FLAG,DID  
       )  
       SELECT P.Person_Number ,  
           P.Person_ID ,   
           '' as DEPENDENT_ID,  
         Issuing_Country_Name as COUNTRY,          
         Passport_Number ,  
         Passport_Issue_Date ,  
         --CASE WHEN CONVERT(DATE,GETDATE(),103)<= CONVERT(DATE,Passport_Expiration_Date,103) THEN 'Y' ELSE 'N' END as HEX_ACTIVE_PSPT,  
         Passport_Expiration_Date ,   
         Issuing_Country_Name ,  
         '' as STATE_PASSPORT,  
         Passport_Issuing_Location ,  
         Passport_Issuing_Authority ,  
         Passport_ID,          
         'N',@DID  
       FROM OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_Passport/Person/Passports/Passport/Passport_Details', 2) WITH (  
         Person_ID NVARCHAR(20) ,  
         Person_Number NVARCHAR(20),  
         Issuing_Country_Name NVARCHAR(100),  
         Passport_Number NVARCHAR(30),  
         Passport_Issue_Date DATE,  
         Passport_Expiration_Date DATE,  
         Passport_Issuing_Location NVARCHAR(100),  
         Passport_Issuing_Authority NVARCHAR(100),  
         Passport_ID NVARCHAR(30)  
         )C    
         JOIN     
         (  
         (SELECT     
          Person_ID , Person_Number    
         FROM     
          OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_Passport/Person/Person_Details',2)    
          WITH     
          (      
           Person_ID NVARCHAR(100),      
           Person_Number NVARCHAR(200)    
          )     
         )) P ON P.Person_ID = C.Person_ID    
      
      END   
        
      SET @StrRaiseError= 'Xml to Staging table process completed for the file ... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
      SET @StrRaiseError= 'Transform Process start... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   --- TRANSFORM LOGIC START  
        
      UPDATE A   
       SET A.EMPLID=RIGHT(EMPLID,5)
	   , COUNTRY = dbo.GET_MAPPING_INFO('COUNTRY', COUNTRY)    
       ,COUNTRY_PASSPORT = dbo.GET_MAPPING_INFO('COUNTRY', COUNTRY_PASSPORT)   
       ,HEX_ACTIVE_PSPT=CASE WHEN CONVERT(DATE,GETDATE(),103)<= CONVERT(DATE,EXPIRATN_DT,103) THEN 'Y' ELSE 'N' END   
       ,DT_ISSUED = CASE WHEN DT_ISSUED='1900-01-01' THEN NULL ELSE DT_ISSUED END  
       ,EXPIRATN_DT = CASE WHEN EXPIRATN_DT='1900-01-01' THEN NULL ELSE EXPIRATN_DT END      
      FROM PS_CITIZEN_PSSPRT_STG A  
       WHERE A.PROCESS_FLAG='N' AND   
       DID=@DID  
       
     SET @StrRaiseError= 'Transform Process End... '+ @DDOCNAME  
     RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
   --TRANSFORM LOGIC END  
  
  SET @StrRaiseError= 'update XML SYNC file and start picking next XML file.'   
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  UPDATE ORA_CITIZEN_PSSPRT_XML_SYNC SET PROCESS_FLAG=1 ,PROCESSED_DATE=getdate() where DDOCNAME=@DDOCNAME   
    
     
    
  SET @i=@i+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete gloabl temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
 --DROP TABLE ##CITIZEN_PSSPRT_SYNC_A  
 --SELECT * FROM PS_CITIZEN_PSSPRT_STG  
  
 SET @StrRaiseError= 'PartA-XML Sync to Staging Table Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   
 -----------   
  
-- PART B - Staging Table to PeopleSoft Table  
  
 if object_id('tempdb..##CITIZEN_PSSPRT_SYNC_B') is not null  
 begin  
  drop table ##CITIZEN_PSSPRT_SYNC_B  
 end  
   
 --CREATE TABLE ##CITIZEN_PSSPRT_SYNC_B -- Declaring a temporary table  
 -- (    
 --  TABLEID DECIMAL,  
 --   EMPLID NVARCHAR(11),  
 --   PER_STATUS VARCHAR(1),  
 --   BIRTHPLACE VARCHAR(30),  
 --   BIRTHCOUNTRY VARCHAR(3),  
 --   BIRTHSTATE VARCHAR(60),  
 --   DT_OF_DEATH DATE,  
 --   ORIG_HIRE_DT DATE,  
 --   HIGHLY_COMP_EMPL_P VARCHAR(2),  
 --   HIGHLY_COMP_EMPL_C VARCHAR(2),  
 --   HX_IT_EXP DECIMAL,  
 --   HX_YRS_OF_EXP DECIMAL,  
 --   LAST_CHILD_UPDDTM DATE,  
 --   BIRTHDATE DATE,  
 --   PROCESS_FLAG VARCHAR(1),DID INT  
 -- )  
   
 -- INSERT INTO ##CITIZEN_PSSPRT_SYNC_B SELECT ROW_NUMBER() OVER(ORDER BY EMPLID)  
 --  ,EMPLID,PER_STATUS, BIRTHPLACE, BIRTHCOUNTRY,BIRTHSTATE,DT_OF_DEATH  
 --  ,ORIG_HIRE_DT,'N','',HX_IT_EXP,HX_YRS_OF_EXP,LAST_CHILD_UPDDTM,BIRTHDATE  
 --  ,'N' ,DID  
 --  FROM PS_CITIZEN_PSSPRT_STG WHERE PROCESS_FLAG='N'  
     
     select * into ##CITIZEN_PSSPRT_SYNC_B from PS_CITIZEN_PSSPRT_STG where 1=2  
   ALTER TABLE ##CITIZEN_PSSPRT_SYNC_B ADD TABLEID INT  
  
   INSERT INTO ##CITIZEN_PSSPRT_SYNC_B  
    SELECT *,ROW_NUMBER() OVER(ORDER BY EMPLID) FROM PS_CITIZEN_PSSPRT_STG WHERE PROCESS_FLAG='N'  
  
  DECLARE @TotalRecs INT=(SELECT COUNT(1)FROM ##CITIZEN_PSSPRT_SYNC_B )  
  DECLARE @j INT=1  
    
  SET @StrRaiseError= 'PartA-Staging Table to PeopleSoft Table:Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_Recs to be procssed: '   
       + RTRIM(CAST(@TotalRecs AS varchar(10)));  
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  SET @DID=0  
   
 WHILE @j<=@TotalRecs  --Main Loop  
  BEGIN   
   SET @EMPLID=(SELECT EMPLID from ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j)  
   SET @DID=(SELECT DID FROM ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j)  
   SET @PASSPORT_NBR=(SELECT PASSPORT_NBR from ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j)  
   SET @DEPENDENT_ID=(SELECT DEPENDENT_ID from ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j)  
   SET @COUNTRY=(SELECT COUNTRY from ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j)  
  
   SET @StrRaiseError= 'Processing-Employee ID ... '+ @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   SET @RECCNT=(SELECT COUNT(1) FROM PS_CITIZEN_PSSPRT WHERE EMPLID=@EMPLID   
     AND PASSPORT_NBR = ISNULL(@PASSPORT_NBR,'')  
     AND DEPENDENT_ID = ISNULL(@DEPENDENT_ID,'')  
     AND COUNTRY=ISNULL(@COUNTRY,''))  
  
   IF @RECCNT=0   
    BEGIN 

     INSERT INTO PS_CITIZEN_PSSPRT (EMPLID,DEPENDENT_ID,COUNTRY,PASSPORT_NBR,DT_ISSUED,HEX_ACTIVE_PSPT,EXPIRATN_DT,  
     COUNTRY_PASSPORT,STATE_PASSPORT,CITY_PASSPORT,ADDRESS100,HX_REASON_PASSPORT,PHONE,ISSUING_AUTHORITY,ECNR,HEX_APPLIED,  
     HX_NAME_IN_PSSPRT,FILENAME,COMMENTS)  
     SELECT EMPLID,ISNULL(DEPENDENT_ID,''),ISNULL(COUNTRY,''),ISNULL(PASSPORT_NBR,''),ISNULL(DT_ISSUED,''),  
     ISNULL(HEX_ACTIVE_PSPT,''),ISNULL(EXPIRATN_DT,''),  
     ISNULL(COUNTRY_PASSPORT,''),ISNULL(STATE_PASSPORT,''),ISNULL(CITY_PASSPORT,''),ISNULL(ADDRESS100,''),  
     ISNULL(HX_REASON_PASSPORT,''),ISNULL(PHONE,''),  
     ISNULL(ISSUING_AUTHORITY,''),ISNULL(ECNR,''),ISNULL(HEX_APPLIED,''),  
     ISNULL(HX_NAME_IN_PSSPRT,''),
	 ISNULL(FILENAME,''),  
     'FUSION' --ISNULL(COMMENTS,'')  
     FROM ##CITIZEN_PSSPRT_SYNC_B WHERE TABLEID=@j AND EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    END  
   ELSE  
    BEGIN   
  
    --SELECT EMPLID,DEPENDENT_ID,COUNTRY,PASSPORT_NBR,DT_ISSUED,HEX_ACTIVE_PSPT,EXPIRATN_DT,  
    -- COUNTRY_PASSPORT,  
    -- '' STATE_PASSPORT,'' CITY_PASSPORT,'' ADDRESS100,'' HX_REASON_PASSPORT,'' PHONE,'' ISSUING_AUTHORITY,'' ECNR,'' HEX_APPLIED,  
    -- '' HX_NAME_IN_PSSPRT,'' FILENAME,COMMENTS  
    -- FROM ##CITIZEN_PSSPRT_SYNC_B  
  
     UPDATE A   
      SET   
       A.DEPENDENT_ID   = ISNULL(B.DEPENDENT_ID,''),  
       A.COUNTRY    = ISNULL(B.COUNTRY,''),  
       A.PASSPORT_NBR   = ISNULL(B.PASSPORT_NBR,''),  
       A.DT_ISSUED    = ISNULL(B.DT_ISSUED,''),  
       A.HEX_ACTIVE_PSPT  = ISNULL(B.HEX_ACTIVE_PSPT,''),  
       A.EXPIRATN_DT   = ISNULL(B.EXPIRATN_DT,''),  
       A.COUNTRY_PASSPORT  = ISNULL(B.COUNTRY_PASSPORT,''),  
       A.STATE_PASSPORT  = ISNULL(B.STATE_PASSPORT,''),  
       A.CITY_PASSPORT   = ISNULL(B.CITY_PASSPORT,''),  
       A.ADDRESS100   = ISNULL(B.ADDRESS100,''),  
       A.HX_REASON_PASSPORT = ISNULL(B.HX_REASON_PASSPORT,''),  
       A.PHONE     = ISNULL(B.PHONE,''),  
       A.ISSUING_AUTHORITY  = ISNULL(B.ISSUING_AUTHORITY,''),  
       A.ECNR     = ISNULL(B.ECNR,''),  
       A.HEX_APPLIED      = ISNULL(B.HEX_APPLIED,''),  
       A.HX_NAME_IN_PSSPRT  = ISNULL(B.HX_NAME_IN_PSSPRT,''),  
       A.FILENAME    = ISNULL(B.FILENAME,''),  
       A.COMMENTS    = 'FUSION' --ISNULL(B.COMMENTS,'')  
  
     FROM PS_CITIZEN_PSSPRT A,##CITIZEN_PSSPRT_SYNC_B B  
     WHERE A.EMPLID =B.EMPLID COLLATE SQL_Latin1_General_CP1_CI_AS  
     AND A.PASSPORT_NBR= B.PASSPORT_NBR  
     AND A.DEPENDENT_ID = B.DEPENDENT_ID  
     AND A.COUNTRY=B.COUNTRY  
     AND A.EMPLID=@EMPLID AND B.TABLEID=@j AND B.PROCESS_FLAG='N' AND DID=@DID  
    END   
       
   --TRANSFORM LOGIC END  
  
   SET @StrRaiseError= 'updating staging table .'  + @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   UPDATE  PS_CITIZEN_PSSPRT_STG SET PROCESS_FLAG='Y',LASTUPDDTTM=GETDATE()  where EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    
  SET @j=@j+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete the global temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
 DROP TABLE ##CITIZEN_PSSPRT_SYNC_B  
 --SELECT * FROM PS_CITIZEN_PSSPRT  
  
 SET @StrRaiseError= 'Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  -----------  */  
  
  --SELECT DISTINCT * FROM PS_CITIZEN_PSSPRT_STG WHERE EMPLID='11347'  
   
END   
  
  
  