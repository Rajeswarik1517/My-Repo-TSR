--sp_helptext 'USP_PS_EMERGENCY_CNTCT_SYNC'
  
-- SELECT * FROM ORA_EMERGENCY_CNTCT_XML_SYNC where DID IN(849170) -- 849203  
-- select * from ORA_EMERGENCY_CNTCT_XML_SYNC where cast(DTCREATEDDATETIME as date)>'2022-04-04'  
  
-- UPDATE ORA_EMERGENCY_CNTCT_XML_SYNC SET PROCESS_FLAG=0 where cast(DTCREATEDDATETIME as date)>'2022-04-04'  
-- SELECT LEN(EXTRACT_XML),DID FROM ORA_EMERGENCY_CNTCT_XML_SYNC where PROCESS_FLAG=0  
-- TRUNCATE TABLE PS_EMERGENCY_CNTCT_STG  
--SELECT * FROM PS_EMERGENCY_CNTCT_STG WHERE EMPLID='101259'  
  
ALTER PROCEDURE [dbo].[USP_PS_EMERGENCY_CNTCT_SYNC]   
AS  
BEGIN  
  
 DECLARE @DocumentId INT  
 DECLARE @DDOCNAME Varchar(400)  
   
 DECLARE @docHandle int;    
 DECLARE @xmlDocument nvarchar(max); -- or xml type    
   
 DECLARE @StrRaiseError VARCHAR(100);  
  
 DECLARE @RECCNT  INT  
 DECLARE @EMPLID Varchar(11)  
  
 DECLARE @DID INT,@CONTACT_NAME varchar(100),@E_ADDR_TYPE varchar(10)  
   
-- PART A - XML Sync to Staging Table  
   
 --if object_id('tempdb..##EMERGENCY_CNTCT_SYNC_A') is not null  
 --begin  
 -- drop table ##EMERGENCY_CNTCT_SYNC_A  
 --end  
   
 --CREATE TABLE ##EMERGENCY_CNTCT_SYNC_A -- Declaring a temporary table  
 --(  
 -- TABLEID int,  
 -- DID INT,  
 -- DDOCNAME VARCHAR(100)  
 --)  
  
 --INSERT INTO ##EMERGENCY_CNTCT_SYNC_A    
 --SELECT ROW_NUMBER() OVER(ORDER BY DDOCNAME) TABLEID,DID,DDOCNAME FROM ORA_EMERGENCY_CNTCT_XML_SYNC WHERE PROCESS_FLAG=0 ORDER BY DID ASC  
   
 --DECLARE @TotalFiles INT=(SELECT COUNT(1)FROM ##EMERGENCY_CNTCT_SYNC_A)  
 --DECLARE @i INT=1  
 BEGIN TRY 
 DECLARE @tblxml TABLE    
 (    
   U_ID INT IDENTITY(1,1)     
  , DID BIGINT    
  , ENTITYNAME VARCHAR(50)    
  , EXTRACT_XML nvarchar(max)    
  , DDOCNAME VARCHAR(50)    
  )   
  DECLARE @TotalFiles INT   
     
  SELECT @TotalFiles = COUNT(1) FROM ORA_EMERGENCY_CNTCT_XML_SYNC WHERE PROCESS_FLAG = 0    
  INSERT INTO @tblxml (DID, ENTITYNAME, EXTRACT_XML, DDOCNAME)     
  SELECT   DISTINCT  
   DID, ENTITYNAME, EXTRACT_XML, DDOCNAME FROM ORA_EMERGENCY_CNTCT_XML_SYNC     
  WHERE     
   PROCESS_FLAG = 0    
   AND DID NOT IN (SELECT DID FROM PS_EMERGENCY_CNTCT_STG)   
      ORDER BY DID  
      
  DECLARE @i INT=1     
  
   
 SET @StrRaiseError= 'Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_files to be procssed: ' + RTRIM(CAST(@TotalFiles AS varchar(10)));  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   
 WHILE @i<=@TotalFiles  --Main Loop  
  BEGIN   
   --SET @DDOCNAME=(SELECT DDOCNAME from ##EMERGENCY_CNTCT_SYNC_A WHERE TABLEID=@i)  
   --SET @DID= (SELECT DID from ##EMERGENCY_CNTCT_SYNC_A WHERE TABLEID=@i)  
     
   SET @StrRaiseError= 'Processing file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   --SET @XmlDocument=(SELECT EXTRACT_XML FROM ORA_EMERGENCY_CNTCT_XML_SYNC WHERE DDOCNAME=@DDOCNAME AND PROCESS_FLAG=0)  
    SELECT @XmlDocument = EXTRACT_XML  
    , @DDOCNAME = DDOCNAME  
    , @DID = DID   
    from @tblxml WHERE U_ID = @i   
     
   EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDocument;   
     
   SET @StrRaiseError= 'Xml prepare and parsing process completed for the file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   IF @XmlDocument <>''   
      
    SET @StrRaiseError= 'Xml to Staging table for the file ... '+ @DDOCNAME  
    RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
    BEGIN   
--  truncate table  PS_EMERGENCY_CNTCT_STG  
     INSERT INTO PS_EMERGENCY_CNTCT_STG (  
        EMPLID  
        ,CONTACT_NAME  
        ,SAME_ADDRESS_EMPL  
        ,PRIMARY_CONTACT  
        ,COUNTRY  
        ,ADDRESS1  
        ,ADDRESS2  
        ,ADDRESS3  
        ,ADDRESS4  
        ,CITY  
        ,COUNTY  
        ,STATE  
        ,POSTAL  
        ,PHONE  
        ,RELATIONSHIP  
        ,SAME_PHONE_EMPL  
        ,ADDRESS_TYPE  
        ,PHONE_TYPE
		,E_ADDR_TYPE  
        ,EXTENSION  
        ,PROCESS_FLAG,DID  
       )  
       SELECT Person_Number  
         ,First_Name+' '+Last_Name AS CONTACT_NAME  
         ,'N' AS SAME_ADDRESS_EMPL  
         ,PRIMARY_CONTACT  
         ,Country_Code  
         ,Address_Line1  
         ,Address_Line2  
         ,Address_Line3  
         ,Address_Line4  
         ,Town_or_City  
         ,Country_Code  
         ,Derived_Locale  
         ,Postal_Code           
         ,ContactPhone  
         ,CONTACT_TYPE  
         ,'N'   
         ,Address_Type  
         ,PHONE_TYPE
		 ,Address_Type  
         ,PhoneExtension  
         ,'N',@DID  
       FROM OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_EMERGENCY_CNTCT/Person_DG/Contacts_Details/Contacts_DG/Contacts_ER/Contact_Relationships_DG/Contact_Relationships_ER', 2) WITH (  
         Person_ID NVARCHAR(20),  
         First_Name NVARCHAR(100),  
         Last_Name NVARCHAR(100),  
         Country_Code NVARCHAR(10),  
         Address_Line1 NVARCHAR(100),  
         Address_Line2 NVARCHAR(100),  
         Address_Line3 NVARCHAR(100),  
         Address_Line4 NVARCHAR(100),  
         Town_or_City NVARCHAR(100),  
         Postal_Code NVARCHAR(20),  
         Derived_Locale NVARCHAR(100),  
         ContactPhone NVARCHAR(30),  
         PhoneExtension NVARCHAR(10),  
         PHONE_TYPE NVARCHAR(10),  
         CONTACT_RELATIONSHIP_ID NVARCHAR(100),  
         CONTACT_TYPE NVARCHAR(10),  
         Contact_Person_ID NVARCHAR(20),  
         PRIMARY_CONTACT NVARCHAR(20))  
         C    
          JOIN     
         (  
         (SELECT     
          Person_ID , Person_Number    
         FROM     
          OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_EMERGENCY_CNTCT/Person_DG/person_ER',2)    
          WITH     
          (      
           Person_ID NVARCHAR(100),      
           Person_Number NVARCHAR(200)    
          )     
         )) P ON P.Person_ID = C.Person_ID   
          JOIN     
         (  
         (SELECT     
          Person_ID , Address_Type    
         FROM     
          OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_EMERGENCY_CNTCT/Person_DG/Contacts_Details/Contacts_DG/Contacts_ER/Contact_Relationships_DG/Contact_Relationships_ER/Contact_Addresses_DG/Contact_Address_ER',2)    
          WITH     
          (      
           Person_ID NVARCHAR(100),      
           Address_Type NVARCHAR(200)    
          )     
         )) A ON A.Person_ID = C.Person_ID   
      END   
        
      SET @StrRaiseError= 'Xml to Staging table process completed for the file ... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
      SET @StrRaiseError= 'Transform Process start... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   --- TRANSFORM LOGIC START  
        
      UPDATE A   
       SET A.EMPLID=RIGHT(EMPLID,5)  
       ,COUNTRY = dbo.GET_MAPPING_INFO('COUNTRY', COUNTRY)  
	   ,RELATIONSHIP=dbo.GET_MAPPING_INFO_INTERFACE('RELATIONSHIP',RELATIONSHIP)  
      -- ,RELATIONSHIP=CASE RELATIONSHIP   
      -- WHEN 'BROTHER' THEN 'B'  
      -- WHEN 'C' THEN 'O'  
      -- WHEN 'Father-in-' THEN 'D'  
      -- WHEN 'IN_D' THEN 'D'  
      -- WHEN 'IN_FR' THEN 'D'  
      -- WHEN 'IN_MR' THEN 'D'  
      -- WHEN 'IN_S' THEN 'D'  
      -- WHEN 'Mother-in-' THEN 'D'  
      -- WHEN 'O' THEN 'O'  
      -- WHEN 'ORA_HRX_AU' THEN 'O'  
      -- WHEN 'ORA_HRX_HU' THEN 'O'  
      -- WHEN 'S' THEN 'O'  
      -- WHEN 'SISTER' THEN 'B'  
      -- ELSE 'O'   
      --END   
      FROM PS_EMERGENCY_CNTCT_STG A  
       WHERE A.PROCESS_FLAG='N' AND DID=@DID       
       
  
     SET @StrRaiseError= 'Transform Process End... '+ @DDOCNAME  
     RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
   --TRANSFORM LOGIC END  
  
  SET @StrRaiseError= 'update XML SYNC file and start picking next XML file.'   
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
 UPDATE  ORA_EMERGENCY_CNTCT_XML_SYNC SET PROCESS_FLAG=1 ,PROCESSED_DATE=getdate() where DDOCNAME=@DDOCNAME   
    
     
    
  SET @i=@i+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete gloabl temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
 --DROP TABLE ##EMERGENCY_CNTCT_SYNC_A  
 --SELECT * FROM PS_EMERGENCY_CNTCT_STG  
  
 SET @StrRaiseError= 'PartA-XML Sync to Staging Table Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   
 -----------   
  
-- PART B - Staging Table to PeopleSoft Table  
  
 if object_id('tempdb..##EMERGENCY_CNTCT_SYNC_B') is not null  
 begin  
  drop table ##EMERGENCY_CNTCT_SYNC_B  
 end  
   
 --CREATE TABLE ##PERSON_SYNC_B -- Declaring a temporary table  
 -- (    
 --  TABLEID DECIMAL,  
 --   EMPLID NVARCHAR(11),  
 --   PER_STATUS VARCHAR(1),  
 --   BIRTHPLACE VARCHAR(30),  
 --   BIRTHCOUNTRY VARCHAR(3),  
 --   BIRTHSTATE VARCHAR(60),  
 --   DT_OF_DEATH DATE,  
 --   ORIG_HIRE_DT DATE,  
 --   HIGHLY_COMP_EMPL_P VARCHAR(2),  
 --   HIGHLY_COMP_EMPL_C VARCHAR(2),  
 --   HX_IT_EXP DECIMAL,  
 --   HX_YRS_OF_EXP DECIMAL,  
 --   LAST_CHILD_UPDDTM DATE,  
 --   BIRTHDATE DATE,  
 --   PROCESS_FLAG VARCHAR(1),DID INT  
 -- )  
   
 -- INSERT INTO ##PERSON_SYNC_B SELECT ROW_NUMBER() OVER(ORDER BY EMPLID)  
 --  ,EMPLID,PER_STATUS, BIRTHPLACE, BIRTHCOUNTRY,BIRTHSTATE,DT_OF_DEATH  
 --  ,ORIG_HIRE_DT,'N','',HX_IT_EXP,HX_YRS_OF_EXP,LAST_CHILD_UPDDTM,BIRTHDATE  
 --  ,'N' ,DID  
 --  FROM PS_EMERGENCY_CNTCT_STG WHERE PROCESS_FLAG='N'  
     
    select * into ##EMERGENCY_CNTCT_SYNC_B from PS_EMERGENCY_CNTCT_STG where 1=2  
   ALTER TABLE ##EMERGENCY_CNTCT_SYNC_B ADD TABLEID INT  
  
   INSERT INTO ##EMERGENCY_CNTCT_SYNC_B  
    SELECT *,ROW_NUMBER() OVER(ORDER BY EMPLID) FROM PS_EMERGENCY_CNTCT_STG WHERE PROCESS_FLAG='N'  
  
  DECLARE @TotalRecs INT=(SELECT COUNT(1)FROM ##EMERGENCY_CNTCT_SYNC_B )  
  DECLARE @j INT=1  
    
  SET @StrRaiseError= 'PartA-Staging Table to PeopleSoft Table:Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_Recs to be procssed: '   
       + RTRIM(CAST(@TotalRecs AS varchar(10)));  
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  SET @DID=0  
   
 WHILE @j<=@TotalRecs  --Main Loop  
  BEGIN   
   SET @EMPLID=(SELECT EMPLID from ##EMERGENCY_CNTCT_SYNC_B WHERE TABLEID=@j)  
   SET @DID=(SELECT DID FROM ##EMERGENCY_CNTCT_SYNC_B WHERE TABLEID=@j)  
   SET @CONTACT_NAME=(SELECT CONTACT_NAME from ##EMERGENCY_CNTCT_SYNC_B WHERE TABLEID=@j)  
   SET @E_ADDR_TYPE=(SELECT E_ADDR_TYPE from ##EMERGENCY_CNTCT_SYNC_B WHERE TABLEID=@j)  
     
   SET @StrRaiseError= 'Processing-Employee ID ... '+ @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   SET @RECCNT=(SELECT COUNT(1) FROM PS_EMERGENCY_CNTCT WHERE EMPLID=@EMPLID  
     AND CONTACT_NAME=ISNULL(@CONTACT_NAME,'')  
     AND E_ADDR_TYPE=ISNULL(@E_ADDR_TYPE,''))  
  
   IF @RECCNT=0   
    BEGIN   

	select @EMPLID,@CONTACT_NAME,@E_ADDR_TYPE

     INSERT INTO PS_EMERGENCY_CNTCT (
				EMPLID  
               ,CONTACT_NAME   
               ,SAME_ADDRESS_EMPL   
               ,PRIMARY_CONTACT   
               ,COUNTRY   
               ,ADDRESS1   
               ,ADDRESS2   
               ,ADDRESS3   
               ,ADDRESS4   
               ,CITY   
               ,NUM1   
               ,NUM2   
               ,HOUSE_TYPE   
               ,ADDR_FIELD1   
               ,ADDR_FIELD2   
               ,ADDR_FIELD3   
               ,COUNTY   
               ,STATE   
               ,POSTAL   
               ,GEO_CODE   
               ,IN_CITY_LIMIT   
               ,COUNTRY_CODE   
               ,PHONE   
               ,RELATIONSHIP   
               ,SAME_PHONE_EMPL   
               ,ADDRESS_TYPE   
               ,PHONE_TYPE   
               ,BLOOD_GROUP   
               ,EMAIL_ADDR   
               ,E_ADDR_TYPE   
               ,EXTENSION   
               )  
     SELECT EMPLID 
			   ,ISNULL(CONTACT_NAME   ,'')
               ,ISNULL(SAME_ADDRESS_EMPL ,'')  
               ,ISNULL(PRIMARY_CONTACT  ,'')    
               ,ISNULL(COUNTRY    ,'')  
               ,ISNULL(ADDRESS1    ,'')  
               ,ISNULL(ADDRESS2    ,'')  
               ,ISNULL(ADDRESS3    ,'')  
               ,ISNULL(ADDRESS4    ,'')  
               ,ISNULL(CITY     ,'')  
               ,ISNULL(NUM1     ,'')  
               ,ISNULL(NUM2     ,'')  
               ,ISNULL(HOUSE_TYPE   ,'')  
               ,ISNULL(ADDR_FIELD1   ,'')  
               ,ISNULL(ADDR_FIELD2   ,'')  
               ,ISNULL(ADDR_FIELD3   ,'')  
               ,ISNULL(COUNTY    ,'')  
               ,ISNULL(STATE    ,'')  
               ,ISNULL(POSTAL    ,'')  
               ,ISNULL(GEO_CODE    ,'')  
               ,ISNULL(IN_CITY_LIMIT  ,'')  
               ,ISNULL(COUNTRY_CODE   ,'')  
               ,ISNULL(PHONE    ,'')  
               ,ISNULL(RELATIONSHIP   ,'')  
               ,ISNULL(SAME_PHONE_EMPL  ,'')  
               ,ISNULL(ADDRESS_TYPE   ,'')  
               ,ISNULL(PHONE_TYPE   ,'')  
               ,ISNULL(BLOOD_GROUP   ,'')  
               ,ISNULL(EMAIL_ADDR   ,'')  
               ,ISNULL(E_ADDR_TYPE   ,'')  
               ,ISNULL(EXTENSION   ,'')  
     FROM ##EMERGENCY_CNTCT_SYNC_B WHERE TABLEID=@j AND EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    END  
   ELSE  
    BEGIN   
      --SELECT * FROM ##EMERGENCY_CNTCT_SYNC_B  
     UPDATE A   
      SET A.CONTACT_NAME  = ISNULL(B.CONTACT_NAME  ,''),  
       A.SAME_ADDRESS_EMPL = ISNULL(B.SAME_ADDRESS_EMPL,'')  ,  
       A.PRIMARY_CONTACT = ISNULL(B.PRIMARY_CONTACT ,'')  ,  
       A.COUNTRY   = ISNULL(B.COUNTRY   ,'')  ,  
       A.ADDRESS1   = ISNULL(B.ADDRESS1   ,''),  
       A.ADDRESS2   = ISNULL(B.ADDRESS2   ,''),  
       A.ADDRESS3   = ISNULL(B.ADDRESS3   ,''),  
       A.ADDRESS4   = ISNULL(B.ADDRESS4   ,''),  
       A.CITY    = ISNULL(B.CITY    ,''),  
       A.NUM1    = ISNULL(B.NUM1    ,''),  
       A.NUM2    = ISNULL(B.NUM2    ,''),  
       A.HOUSE_TYPE  = ISNULL(B.HOUSE_TYPE  ,'')  ,  
       A.ADDR_FIELD1  = ISNULL(B.ADDR_FIELD1  ,'')  ,  
       A.ADDR_FIELD2  = ISNULL(B.ADDR_FIELD2  ,'')  ,  
       A.ADDR_FIELD3  = ISNULL(B.ADDR_FIELD3  ,'')  ,  
       A.COUNTY   = ISNULL(B.COUNTY   ,'')  ,  
       A.STATE    = ISNULL(B.STATE   ,'') ,  
       A.POSTAL   = ISNULL(B.POSTAL   ,'')  ,  
       A.GEO_CODE   = ISNULL(B.GEO_CODE   ,''),  
       A.IN_CITY_LIMIT  = ISNULL(B.IN_CITY_LIMIT ,'') ,  
       A.COUNTRY_CODE  = ISNULL(B.COUNTRY_CODE  ,''),  
       A.PHONE    = ISNULL(B.PHONE   ,'') ,  
       A.RELATIONSHIP  = ISNULL(B.RELATIONSHIP  ,''),  
       A.SAME_PHONE_EMPL = ISNULL(B.SAME_PHONE_EMPL ,'')  ,  
       A.ADDRESS_TYPE  = ISNULL(B.ADDRESS_TYPE  ,''),  
       A.PHONE_TYPE  = ISNULL(B.PHONE_TYPE  ,'')  ,  
       A.BLOOD_GROUP  = ISNULL(B.BLOOD_GROUP  ,'')  ,  
       A.EMAIL_ADDR  = ISNULL(B.EMAIL_ADDR  ,'')  ,  
       A.E_ADDR_TYPE  = ISNULL(B.E_ADDR_TYPE  ,'')  ,  
       A.EXTENSION   = ISNULL(B.EXTENSION  ,'')   
     FROM PS_EMERGENCY_CNTCT A,##EMERGENCY_CNTCT_SYNC_B B  
     WHERE A.EMPLID =B.EMPLID COLLATE SQL_Latin1_General_CP1_CI_AS   
     AND A.CONTACT_NAME=B.CONTACT_NAME  
     AND A.E_ADDR_TYPE=B.E_ADDR_TYPE  
     AND A.EMPLID=@EMPLID AND B.TABLEID=@j AND B.PROCESS_FLAG='N' AND DID=@DID  
    END   
       
   --TRANSFORM LOGIC END  
  
   SET @StrRaiseError= 'updating staging table .'  + @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   UPDATE  PS_EMERGENCY_CNTCT_STG SET PROCESS_FLAG='Y',LASTUPDDTTM=GETDATE()  where EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    
  SET @j=@j+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete the global temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
 DROP TABLE ##EMERGENCY_CNTCT_SYNC_B  
 --SELECT * FROM PS_EMERGENCY_CNTCT  
  
 SET @StrRaiseError= 'Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  -----------  */  
END TRY
BEGIN CATCH

 SELECT
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_STATE() AS ErrorState,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage;

END CATCH
   
END   
  
  
  
  