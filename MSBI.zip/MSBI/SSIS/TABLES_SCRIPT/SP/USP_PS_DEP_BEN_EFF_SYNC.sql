USE [HCM92DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--SELECT LEN(EXTRACT_XML), CONVERT(XML,EXTRACT_XML) , DDOCNAME, DID ,ID, PROCESS_FLAG, DTCREATEDDATETIME 
--FROM ORA_DEP_BEN_EFF_XML_SYNC ORDER BY DTCREATEDDATETIME DESC

/*
  UPDATE ORA_DEP_BEN_EFF_XML_SYNC SET PROCESS_FLAG=0
  truncate table PS_DEP_BEN_EFF_STG

  EXEC USP_PS_DEP_BEN_EFF_SYNC

  */

--ALTER TABLE PS_DEP_BEN_EFF_STG ADD RELATION_SHIP_FULL_NAME NVARCHAR(100)
--ALTER TABLE PS_DEP_BEN_EFF_STG ADD RELATIONSHIP_ID NVARCHAR(30)
--ALTER TABLE PS_DEP_BEN_EFF_STG alter column RELATIONSHIP NVARCHAR(100)


ALTER PROCEDURE [dbo].[USP_PS_DEP_BEN_EFF_SYNC] 
AS
BEGIN

	DECLARE @DocumentId INT
	DECLARE @DDOCNAME Varchar(400)
	
	DECLARE @docHandle int;  
	DECLARE @xmlDocument nvarchar(max); -- or xml type  
	
	DECLARE @StrRaiseError VARCHAR(100);

	DECLARE @RECCNT  INT
	DECLARE @EMPLID Varchar(11)

	DECLARE @DID INT , @DEPENDENT_BENEF VARCHAR(10), @EFFDT DATETIME
	
-- PART A - XML Sync to Staging Table
	

 DECLARE @tblxml TABLE  
 (  
   U_ID INT IDENTITY(1,1)   
  , DID BIGINT  
  , ENTITYNAME VARCHAR(50)  
  , EXTRACT_XML nvarchar(max)  
  , DDOCNAME VARCHAR(50)  
  ) 
  DECLARE @TotalFiles INT 
   
  SELECT @TotalFiles = COUNT(1) FROM ORA_DEP_BEN_EFF_XML_SYNC WHERE PROCESS_FLAG = 0  
  INSERT INTO @tblxml (DID, ENTITYNAME, EXTRACT_XML, DDOCNAME)   
  SELECT   DISTINCT
   DID, ENTITYNAME, EXTRACT_XML, DDOCNAME FROM ORA_DEP_BEN_EFF_XML_SYNC   
  WHERE   
   PROCESS_FLAG = 0  
   AND DID NOT IN (SELECT DID FROM PS_DEP_BEN_EFF_STG)  
	 DECLARE @i INT=1   
	 	 	
	SET @StrRaiseError= 'Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_files to be procssed: ' + RTRIM(CAST(@TotalFiles AS varchar(10)));
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

  WHILE @i <= @TotalFiles  --Main Loop
		BEGIN 
			--SET @DDOCNAME=(SELECT DDOCNAME from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)
			--SET @DID= (SELECT DID from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)
			
			SET @StrRaiseError= 'Processing file ... '+ @DDOCNAME
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
						
			 SELECT @XmlDocument = EXTRACT_XML
			 , @DDOCNAME = DDOCNAME
			 , @DID = DID 
			 from @tblxml WHERE U_ID = @i 
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDocument; 
			
			SET @StrRaiseError= 'Xml prepare and parsing process completed for the file ... '+ @DDOCNAME
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
			IF @XmlDocument <>'' 
				
				SET @StrRaiseError= 'Xml to Staging table for the file ... '+ @DDOCNAME
				RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
--TRUNCATE TABLE PS_DEP_BEN_EFF_STG
				BEGIN 
					INSERT INTO PS_DEP_BEN_EFF_STG (
							EMPLID
							,DEPENDENT_BENEF
							,EFFDT
							,RELATIONSHIP
							,DEP_BENEF_TYPE
							,MAR_STATUS
							,MAR_STATUS_DT
							,SEX
							,OCCUPATION
							,STUDENT
							,DISABLED
							,SMOKER
							,RELATION_SHIP_FULL_NAME
							,RELATIONSHIP_ID							
							,PROCESS_FLAG
							,DID
							)
							SELECT    P.Person_Number  
									,''
									,Effective_Start_Date 
									,RELATIONSHIP 
									,''
									,Marital_Status 
									,Marital_Status_Date 
									,Sex 
									,''
									,''
									,''
									,''
									,Contact_Full_Name
									,Relationship_Id									
									,'N',@DID
							FROM OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PS_DEP_BEN/Person_DG/Contacts_Details/Contacts_DG/Contacts_ER/Contact_Relationships_DG/Contact_Relationships_ER', 2) WITH (
									Person_Number NVARCHAR(20) 
									,Effective_Start_Date DATETIME
									,Marital_Status NVARCHAR(20)
									,Marital_Status_Date DATETIME
									,Sex NVARCHAR(20)
									,Person_ID NVARCHAR(20)
									,RELATIONSHIP NVARCHAR(100)
									,Relationship_Id NVARCHAR(50)
									,Contact_Full_Name nvarchar(100)																	
									)C  
									JOIN   
									(
									(SELECT   
									 Person_ID , Person_Number  
									FROM   
									 OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PS_DEP_BEN/Person_DG/person_ER',2)  
									 WITH   
									 (    
									  Person_ID NVARCHAR(100),    
									  Person_Number NVARCHAR(200),
									  DT_OF_DEATH date  
									 )   
									)) P ON P.Person_Number = C.Person_Number --and P.Person_ID = C.Assignment_ID  
    
						END 
						
						SET @StrRaiseError= 'Xml to Staging table process completed for the file ... '+ @DDOCNAME
						RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
					
						SET @StrRaiseError= 'Transform Process start... '+ @DDOCNAME
						RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			--- TRANSFORM LOGIC START
						
						UPDATE A 
							SET A.EMPLID=RIGHT(EMPLID,5)
							,DEP_BENEF_TYPE=CASE DEP_BENEF_TYPE 
							WHEN 'BROTHER' THEN 'B'
							WHEN 'C' THEN 'O'
							WHEN 'Father-in-' THEN 'D'
							WHEN 'IN_D' THEN 'D'
							WHEN 'IN_FR' THEN 'D'
							WHEN 'IN_MR' THEN 'D'
							WHEN 'IN_S' THEN 'D'
							WHEN 'Mother-in-' THEN 'D'
							WHEN 'O' THEN 'O'
							WHEN 'ORA_HRX_AU' THEN 'O'
							WHEN 'ORA_HRX_HU' THEN 'O'
							WHEN 'S' THEN 'O'
							WHEN 'SISTER' THEN 'B'
							ELSE 'O' 
						END 

						FROM PS_DEP_BEN_EFF_STG A
							WHERE A.PROCESS_FLAG='N' AND DID=@DID
					
					UPDATE 
						PS_DEP_BEN_EFF_STG 
					SET 
						DEPENDENT_BENEF = DEPENDENT_BENEF_DERIVED
					FROM 
						PS_DEP_BEN_EFF_STG PRNT
						LEFT OUTER JOIN 
						(
							SELECT 
								REPLICATE('0', 1) + CONVERT(VARCHAR(2), ROW_NUMBER() OVER(PARTITION BY EMPLID, RELATIONSHIP_ID, DEP_BENEF_TYPE	ORDER BY EMPLID ASC)) AS DEPENDENT_BENEF_DERIVED,  
								EMPLID
							,	RELATIONSHIP_ID
							--,	RELATION_SHIP_FULL_NAME
							,	DEP_BENEF_TYPE
							FROM PS_DEP_BEN_EFF_STG 
							GROUP BY EMPLID,  RELATIONSHIP_ID, --RELATION_SHIP_FULL_NAME, 
							DEP_BENEF_TYPE	
							) AS BENEF_MAIN ON PRNT.EMPLID = BENEF_MAIN.EMPLID 
							AND  PRNT.RELATIONSHIP_ID = BENEF_MAIN.RELATIONSHIP_ID 
							--AND  PRNT.RELATION_SHIP_FULL_NAME = BENEF_MAIN.RELATION_SHIP_FULL_NAME 
							AND PRNT.DEP_BENEF_TYPE = BENEF_MAIN.DEP_BENEF_TYPE



					SET @StrRaiseError= 'Transform Process End... '+ @DDOCNAME
					RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
					
			--TRANSFORM LOGIC END

		SET @StrRaiseError= 'update XML SYNC file and start picking next XML file.'	
		RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		UPDATE ORA_DEP_BEN_EFF_XML_SYNC SET PROCESS_FLAG=1 ,PROCESSED_DATE=getdate() where DDOCNAME=@DDOCNAME 
		
		 
		
		SET @i=@i+1

	END -- While loop ends here
	
	SET @StrRaiseError= 'delete gloabl temp table... '
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
		
	
	--SELECT * FROM PS_DEP_BEN_EFF_STG

	SET @StrRaiseError= 'PartA-XML Sync to Staging Table Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
	
	----------- 

-- PART B - Staging Table to PeopleSoft Table

	if object_id('tempdb..##PS_DEP_BEN_EFF_SYNC_B') is not null
	begin
		drop table ##PS_DEP_BEN_EFF_SYNC_B
	end
	
	--CREATE TABLE ##PERSON_SYNC_B -- Declaring a temporary table
	--	(		
	--		TABLEID DECIMAL,
	--			EMPLID NVARCHAR(11),
	--			PER_STATUS VARCHAR(1),
	--			BIRTHPLACE VARCHAR(30),
	--			BIRTHCOUNTRY VARCHAR(3),
	--			BIRTHSTATE VARCHAR(60),
	--			DT_OF_DEATH DATE,
	--			ORIG_HIRE_DT DATE,
	--			HIGHLY_COMP_EMPL_P VARCHAR(2),
	--			HIGHLY_COMP_EMPL_C VARCHAR(2),
	--			HX_IT_EXP DECIMAL,
	--			HX_YRS_OF_EXP DECIMAL,
	--			LAST_CHILD_UPDDTM DATE,
	--			BIRTHDATE DATE,
	--			PROCESS_FLAG VARCHAR(1),DID INT
	--	)
	
		--INSERT INTO ##PERSON_SYNC_B SELECT ROW_NUMBER() OVER(ORDER BY EMPLID)
		--	,EMPLID,PER_STATUS, BIRTHPLACE, BIRTHCOUNTRY,BIRTHSTATE,DT_OF_DEATH
		--	,ORIG_HIRE_DT,'N','',HX_IT_EXP,HX_YRS_OF_EXP,LAST_CHILD_UPDDTM,BIRTHDATE
		--	,'N' ,DID
		--	FROM PS_DEP_BEN_EFF_STG WHERE PROCESS_FLAG='N'
	  
	  select * into ##PS_DEP_BEN_EFF_SYNC_B from PS_DEP_BEN_EFF_STG where 1=2
	  ALTER TABLE ##PS_DEP_BEN_EFF_SYNC_B ADD TABLEID INT

	  INSERT INTO ##PS_DEP_BEN_EFF_SYNC_B
	   SELECT *,ROW_NUMBER() OVER(ORDER BY EMPLID) FROM PS_DEP_BEN_EFF_STG WHERE PROCESS_FLAG='N'
	  
		DECLARE @TotalRecs INT=(SELECT COUNT(1)FROM ##PS_DEP_BEN_EFF_SYNC_B )
		DECLARE @j INT=1
		
		SET @StrRaiseError= 'PartA-Staging Table to PeopleSoft Table:Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_Recs to be procssed: ' 
							+ RTRIM(CAST(@TotalRecs AS varchar(10)));
		RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		SET @DID=0
	
	WHILE @j<=@TotalRecs  --Main Loop
		BEGIN 
			SET @EMPLID=(SELECT EMPLID from ##PS_DEP_BEN_EFF_SYNC_B WHERE TABLEID=@j)
			SET @DID=(SELECT DID FROM ##PS_DEP_BEN_EFF_SYNC_B WHERE TABLEID=@j)
			SET @DEPENDENT_BENEF=(SELECT DEPENDENT_BENEF FROM ##PS_DEP_BEN_EFF_SYNC_B WHERE TABLEID=@j)
			SET @EFFDT=(SELECT EFFDT FROM ##PS_DEP_BEN_EFF_SYNC_B WHERE TABLEID=@j)
			
			SET @StrRaiseError= 'Processing-Employee ID ... '+ @EMPLID
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
			SET @RECCNT=(SELECT COUNT(1) FROM PS_DEP_BEN_EFF WHERE EMPLID=@EMPLID
					AND DEPENDENT_BENEF=@DEPENDENT_BENEF
					AND CONVERT(DATE,EFFDT)=CONVERT(DATE,@EFFDT))

			IF @RECCNT=0 
				BEGIN 
				print '-------1-----------'
					INSERT INTO PS_DEP_BEN_EFF (EMPLID
												,DEPENDENT_BENEF
												,EFFDT
												,RELATIONSHIP
												,DEP_BENEF_TYPE
												,MAR_STATUS
												,MAR_STATUS_DT
												,SEX
												,OCCUPATION
												,STUDENT
												,DISABLED
												,STUDENT_STATUS_DT
												,DISABLED_STATUS_DT
												,SMOKER
												,SMOKER_DT)
					SELECT   EMPLID
							 ,ISNULL(DEPENDENT_BENEF    ,'')
							 ,ISNULL(EFFDT				,'')
							 ,ISNULL(RELATIONSHIP		,'')
							 ,ISNULL(DEP_BENEF_TYPE		,'')
							 ,ISNULL(MAR_STATUS			,'')
							 ,ISNULL(MAR_STATUS_DT		,'')
							 ,ISNULL(SEX				,'')
							 ,ISNULL(OCCUPATION			,'')
							 ,ISNULL(STUDENT			,'')
							 ,ISNULL(DISABLED			,'')
							 ,ISNULL(STUDENT_STATUS_DT	,'')
							 ,ISNULL(DISABLED_STATUS_DT	,'')
							 ,ISNULL(SMOKER				,'')
							 ,ISNULL(SMOKER_DT			,'')
					FROM ##PS_DEP_BEN_EFF_SYNC_B WHERE TABLEID=@j AND EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID


				END
			ELSE
				BEGIN 
				print '-------2-----------'
				
					UPDATE A 
						SET 
						A.DEPENDENT_BENEF		= ISNULL(B.DEPENDENT_BENEF,''),
						A.EFFDT					= ISNULL(B.EFFDT,''),
						A.RELATIONSHIP			= ISNULL(B.RELATIONSHIP		   ,'')  ,
						A.DEP_BENEF_TYPE		= ISNULL(B.DEP_BENEF_TYPE	   ,'')	 ,
						A.MAR_STATUS			= ISNULL(B.MAR_STATUS		   ,'')	 ,
						A.MAR_STATUS_DT			= ISNULL(B.MAR_STATUS_DT		,'') ,
						A.SEX					= ISNULL(B.SEX				   ,'')	 ,
						A.OCCUPATION			= ISNULL(B.OCCUPATION		   ,'')	 ,
						A.STUDENT				= ISNULL(B.STUDENT			   ,'')	 ,
						A.DISABLED				= ISNULL(B.DISABLED			   ,'')	 ,
						A.STUDENT_STATUS_DT		= ISNULL(B.STUDENT_STATUS_DT	,'') ,
						A.DISABLED_STATUS_DT	= ISNULL(B.DISABLED_STATUS_DT  ,'')	 ,
						A.SMOKER				= ISNULL(B.SMOKER			   ,'')	 ,
						A.SMOKER_DT				= ISNULL(B.SMOKER_DT			,'') 
					FROM PS_DEP_BEN_EFF A,##PS_DEP_BEN_EFF_SYNC_B B
					WHERE A.EMPLID =B.EMPLID COLLATE SQL_Latin1_General_CP1_CI_AS 
					AND A.DEPENDENT_BENEF=B.DEPENDENT_BENEF
					AND CONVERT(DATE,A.EFFDT)=CONVERT(DATE,B.EFFDT)
					AND A.EMPLID=@EMPLID AND B.TABLEID=@j AND B.PROCESS_FLAG='N' AND DID=@DID


				END 
					
			--TRANSFORM LOGIC END

			SET @StrRaiseError= 'updating staging table .'	 + @EMPLID
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		 UPDATE 	PS_DEP_BEN_EFF_STG SET PROCESS_FLAG='Y'  where EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID		

		SET @j=@j+1

	END -- While loop ends here
	
	SET @StrRaiseError= 'delete the global temp table... '
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
		
	DROP TABLE ##PS_DEP_BEN_EFF_SYNC_B
	--SELECT * FROM PS_DEP_BEN_EFF

	SET @StrRaiseError= 'Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

	 -----------  */
	
END	



