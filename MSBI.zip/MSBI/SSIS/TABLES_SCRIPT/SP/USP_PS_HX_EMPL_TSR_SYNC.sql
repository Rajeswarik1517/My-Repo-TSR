USE [HCM92DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--select * from PS_HX_EMPL_TSR_TBL_STG where EMPLID='00223'
--select * from PS_HX_EMPL_TSR_TBL_STG where EMPLID= '56039'--'00224'
--select * from PS_HX_EMPL_TSR_TBL where EMPLID='56039'

-- select * from PS_HX_EMPL_TSR_TBL_STG
-- TRUNCATE TABLE PS_HX_EMPL_TSR_TBL_STG

-- SELECT * FROM ORA_HX_EMPL_TSR_TBL_XML_SYNC
 -- UPDATE ORA_HX_EMPL_TSR_TBL_XML_SYNC SET PROCESS_FLAG=1
-- UPDATE ORA_HX_EMPL_TSR_TBL_XML_SYNC SET PROCESS_FLAG=0 where --DID IN(844566,844620,835381) and 
--cast(DTCREATEDDATETIME as date)>'2022-04-04'
-- SELECT LEN(EXTRACT_XML),DID FROM ORA_HX_EMPL_TSR_TBL_XML_SYNC

--SELECT * FROM PS_HX_EMPL_TSR_TBL WHERE EMPLID='15003'
--SELECT len(CREATED_BY),* FROM PS_HX_EMPL_TSR_TBL_STG WHERE EMPLID='15003'

ALTER PROCEDURE [dbo].[USP_PS_HX_EMPL_TSR_SYNC] 
AS
BEGIN

	DECLARE @DocumentId INT
	DECLARE @DDOCNAME Varchar(400)
	
	DECLARE @docHandle int;  
	DECLARE @xmlDocument nvarchar(max); -- or xml type  
	
	DECLARE @StrRaiseError VARCHAR(100);

	DECLARE @RECCNT  INT
	DECLARE @EMPLID Varchar(11)

	DECLARE @DID INT,@CAND_ID VARCHAR(20),@HX_BASE_TSR VARCHAR(100), @EFFDT_FROM DATETIME
	
-- PART A - XML Sync to Staging Table
	

 DECLARE @tblxml TABLE  
 (  
   U_ID INT IDENTITY(1,1)   
  , DID BIGINT  
  , ENTITYNAME VARCHAR(50)  
  , EXTRACT_XML nvarchar(max)  
  , DDOCNAME VARCHAR(50)  
  ) 
  DECLARE @TotalFiles INT 
   
  SELECT @TotalFiles = COUNT(1) FROM ORA_HX_EMPL_TSR_TBL_XML_SYNC WHERE PROCESS_FLAG = 0  
  INSERT INTO @tblxml (DID, ENTITYNAME, EXTRACT_XML, DDOCNAME)   
  SELECT   DISTINCT
   DID, ENTITYNAME, EXTRACT_XML, DDOCNAME FROM ORA_HX_EMPL_TSR_TBL_XML_SYNC   
  WHERE   
   PROCESS_FLAG = 0  
   AND DID NOT IN (SELECT DID FROM PS_HX_EMPL_TSR_TBL_STG)  
      ORDER BY DID
	 DECLARE @i INT=1   
	 	 	
	SET @StrRaiseError= 'Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_files to be procssed: ' + RTRIM(CAST(@TotalFiles AS varchar(10)));
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

  WHILE @i <= @TotalFiles  --Main Loop
		BEGIN 
			--SET @DDOCNAME=(SELECT DDOCNAME from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)
			--SET @DID= (SELECT DID from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)
			
			SET @StrRaiseError= 'Processing file ... '+ @DDOCNAME
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
						
			 SELECT @XmlDocument = EXTRACT_XML
			 , @DDOCNAME = DDOCNAME
			 , @DID = DID 
			 from @tblxml WHERE U_ID = @i 
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDocument; 
			
			SET @StrRaiseError= 'Xml prepare and parsing process completed for the file ... '+ @DDOCNAME
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
			IF @XmlDocument <>'' 
				
				SET @StrRaiseError= 'Xml to Staging table for the file ... '+ @DDOCNAME
				RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
--TRUNCATE TABLE PS_HX_EMPL_TSR_TBL_STG
				BEGIN 
					INSERT INTO PS_HX_EMPL_TSR_TBL_STG (
							CAND_ID
							,EMPLID
							,PersonID
							,HX_BASE_TSR
							,EFFDT_FROM
							,EFFDT_TO
							,APPLID
							,CREATED_DTTM
							,CREATED_BY
							,LASTUPDDTTM
							,LASTUPDOPRID
							,Assignment_ID
							,PROCESS_FLAG
							,DID
							)
							SELECT    '',
									Employee_Number,						
								   P.Person_ID	,						
								   AssignmentName,
								   FromDate,
								   ToDate,
								   'FUSION' ,--BusinessUnitName,
								   CreationDate,
								   CreatedBy,
								   LastUpdateDate,
								   LastUpdateBy,
								   Assignment_ID,
									'N',@DID
							FROM OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PERSON_TSR_DETAILS/Person_DG/Person_TSR_Details/TSR_DG/TSR_Details', 2) WITH (
									Employee_Number NVARCHAR(20) ,
									AssignmentName NVARCHAR(100),
									Assignment_ID NVARCHAR(100),
									FromDate DATETIME,
									ToDate DATETIME,
									BusinessUnitName NVARCHAR(20),
									CreationDate DATETIME,
									CreatedBy NVARCHAR(100),
									LastUpdateDate DATETIME,
									LastUpdateBy NVARCHAR(100)									
									)C  
									JOIN   
									(
									(SELECT   
									 Person_ID , Person_Number  
									FROM   
									 OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PERSON_TSR_DETAILS/Person_DG/PersonDetails',2)  
									 WITH   
									 (    
									  Person_ID NVARCHAR(100),    
									  Person_Number NVARCHAR(200)  
									 )   
									)) P ON P.Person_Number = C.Employee_Number --and P.Person_ID = C.Assignment_ID  
    
						END 
						
						SET @StrRaiseError= 'Xml to Staging table process completed for the file ... '+ @DDOCNAME
						RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
					
						SET @StrRaiseError= 'Transform Process start... '+ @DDOCNAME
						RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			--- TRANSFORM LOGIC START
						
						UPDATE A 
							SET A.EMPLID=RIGHT(EMPLID,5)
						FROM PS_HX_EMPL_TSR_TBL_STG A
							WHERE A.PROCESS_FLAG='N' AND DID=@DID
					
					SET @StrRaiseError= 'Transform Process End... '+ @DDOCNAME
					RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
					
			--TRANSFORM LOGIC END

		SET @StrRaiseError= 'update XML SYNC file and start picking next XML file.'	
		RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		UPDATE ORA_HX_EMPL_TSR_TBL_XML_SYNC SET PROCESS_FLAG=1 ,PROCESSED_DATE=getdate() where DDOCNAME=@DDOCNAME 
		
		 
		
		SET @i=@i+1

	END -- While loop ends here
	
	SET @StrRaiseError= 'delete gloabl temp table... '
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
		
	
	--SELECT * FROM PS_HX_EMPL_TSR_TBL_STG

	SET @StrRaiseError= 'PartA-XML Sync to Staging Table Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
	
	----------- 

-- PART B - Staging Table to PeopleSoft Table

	if object_id('tempdb..##PS_HX_EMPL_TSR_SYNC_B') is not null
	begin
		drop table ##PS_HX_EMPL_TSR_SYNC_B
	end
	
	--CREATE TABLE ##PERSON_SYNC_B -- Declaring a temporary table
	--	(		
	--		TABLEID DECIMAL,
	--			EMPLID NVARCHAR(11),
	--			PER_STATUS VARCHAR(1),
	--			BIRTHPLACE VARCHAR(30),
	--			BIRTHCOUNTRY VARCHAR(3),
	--			BIRTHSTATE VARCHAR(60),
	--			DT_OF_DEATH DATE,
	--			ORIG_HIRE_DT DATE,
	--			HIGHLY_COMP_EMPL_P VARCHAR(2),
	--			HIGHLY_COMP_EMPL_C VARCHAR(2),
	--			HX_IT_EXP DECIMAL,
	--			HX_YRS_OF_EXP DECIMAL,
	--			LAST_CHILD_UPDDTM DATE,
	--			BIRTHDATE DATE,
	--			PROCESS_FLAG VARCHAR(1),DID INT
	--	)
	
		--INSERT INTO ##PERSON_SYNC_B SELECT ROW_NUMBER() OVER(ORDER BY EMPLID)
		--	,EMPLID,PER_STATUS, BIRTHPLACE, BIRTHCOUNTRY,BIRTHSTATE,DT_OF_DEATH
		--	,ORIG_HIRE_DT,'N','',HX_IT_EXP,HX_YRS_OF_EXP,LAST_CHILD_UPDDTM,BIRTHDATE
		--	,'N' ,DID
		--	FROM PS_HX_EMPL_TSR_TBL_STG WHERE PROCESS_FLAG='N'
	  
	  select * into ##PS_HX_EMPL_TSR_SYNC_B from PS_HX_EMPL_TSR_TBL_STG where 1=2
	  ALTER TABLE ##PS_HX_EMPL_TSR_SYNC_B ADD TABLEID INT

	  INSERT INTO ##PS_HX_EMPL_TSR_SYNC_B
	   SELECT *,ROW_NUMBER() OVER(ORDER BY EMPLID) FROM PS_HX_EMPL_TSR_TBL_STG WHERE PROCESS_FLAG='N'
	  
		DECLARE @TotalRecs INT=(SELECT COUNT(1)FROM ##PS_HX_EMPL_TSR_SYNC_B )
		DECLARE @j INT=1
		
		SET @StrRaiseError= 'PartA-Staging Table to PeopleSoft Table:Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_Recs to be procssed: ' 
							+ RTRIM(CAST(@TotalRecs AS varchar(10)));
		RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		SET @DID=0
	
	WHILE @j<=@TotalRecs  --Main Loop
		BEGIN 
			SET @EMPLID=(SELECT EMPLID from ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j)
			SET @DID=(SELECT DID FROM ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j)
			SET @CAND_ID=(SELECT CAND_ID FROM ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j)
			SET @HX_BASE_TSR=(SELECT HX_BASE_TSR FROM ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j)
			SET @EFFDT_FROM=(SELECT EFFDT_FROM FROM ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j)
			
			SET @StrRaiseError= 'Processing-Employee ID ... '+ @EMPLID
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
			
			SET @RECCNT=(SELECT COUNT(1) FROM PS_HX_EMPL_TSR_TBL WHERE EMPLID=@EMPLID
					AND CAND_ID=@CAND_ID
					AND HX_BASE_TSR=@HX_BASE_TSR
					AND CONVERT(DATE,EFFDT_FROM)=CONVERT(DATE,@EFFDT_FROM))

			IF @RECCNT=0 
				BEGIN 
				print '-------1-----------'
					INSERT INTO PS_HX_EMPL_TSR_TBL (CAND_ID
													,EMPLID
													,HX_BASE_TSR
													,EFFDT_FROM
													,EFFDT_TO
													,APPLID
													,CREATED_DTTM
													,CREATED_BY
													,LASTUPDDTTM
													,LASTUPDOPRID)
					SELECT   ISNULL(CAND_ID		,'')
							,ISNULL(EMPLID		,'')
							,ISNULL(HX_BASE_TSR	,'')
							,ISNULL(EFFDT_FROM	,'')
							,ISNULL(EFFDT_TO	,'')
							,ISNULL(APPLID		,'')
							,ISNULL(CREATED_DTTM,'')
							,'' --ISNULL(CREATED_BY	,'')
							,ISNULL(LASTUPDDTTM	,'')
							,'' --ISNULL(LASTUPDOPRID,'')
					FROM ##PS_HX_EMPL_TSR_SYNC_B WHERE TABLEID=@j AND EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID

				END
			ELSE
				BEGIN 
				print '-------2-----------'
				
					UPDATE A 
						SET A.CAND_ID			= ISNULL(B.CAND_ID		,'')
							,A.EMPLID			= ISNULL(B.EMPLID		,'')
							,A.HX_BASE_TSR		= ISNULL(B.HX_BASE_TSR	,'')
							,A.EFFDT_FROM		= ISNULL(B.EFFDT_FROM	,'')
							,A.EFFDT_TO			= ISNULL(B.EFFDT_TO	,'')
							,A.APPLID			= ISNULL(B.APPLID		,'')
							,A.CREATED_DTTM		= ISNULL(B.CREATED_DTTM,'')
							,A.CREATED_BY		= '' --ISNULL(B.CREATED_BY	,'')
							,A.LASTUPDDTTM		= ISNULL(B.LASTUPDDTTM	,'')
							,A.LASTUPDOPRID		= '' --ISNULL(B.LASTUPDOPRID,'')
					FROM PS_HX_EMPL_TSR_TBL A,##PS_HX_EMPL_TSR_SYNC_B B
					WHERE A.EMPLID =B.EMPLID COLLATE SQL_Latin1_General_CP1_CI_AS 
					AND A.CAND_ID=B.CAND_ID
					AND A.HX_BASE_TSR=B.HX_BASE_TSR
					AND CONVERT(DATE,A.EFFDT_FROM)=CONVERT(DATE,B.EFFDT_FROM)
					AND A.EMPLID=@EMPLID AND B.TABLEID=@j AND B.PROCESS_FLAG='N' AND DID=@DID


				END 
					
			--TRANSFORM LOGIC END

			SET @StrRaiseError= 'updating staging table .'	 + @EMPLID
			RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

		UPDATE 	PS_HX_EMPL_TSR_TBL_STG SET PROCESS_FLAG='Y',LASTUPDDTTM=GETDATE() where EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID			
		
		SET @j=@j+1

	END -- While loop ends here
	
	SET @StrRaiseError= 'delete the global temp table... '
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT
		
	DROP TABLE ##PS_HX_EMPL_TSR_SYNC_B
	--SELECT * FROM PS_HX_EMPL_TSR_TBL

	SET @StrRaiseError= 'Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);
	RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT

	 -----------  */
	
END	



