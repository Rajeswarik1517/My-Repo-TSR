USE [HCM92DEV]
GO
-- sp_helptext 'USP_PS_HX_TGA_TBL_SYNC'

  
-- select top 2 * from PS_HX_TGA_TBL  
-- select * from PS_HX_TGA_TBL_STG  
  
  
-- SELECT * FROM ORA_HX_TGA_TBL_XML_SYNC  
/*  
  UPDATE ORA_HX_TGA_TBL_XML_SYNC SET PROCESS_FLAG=0  
  TRUNCATE TABLE PS_HX_TGA_TBL_STG  
  
  EXEC USP_PS_HX_TGA_TBL_SYNC  
  
  SELECT * FROM PS_HX_TGA_TBL_STG WHERE EMPLID='00514'  
  SELECT * FROM PS_HX_TGA_TBL WHERE EMPLID='00514'  
  
  
  */  
  
  
  
ALTER PROCEDURE [dbo].[USP_PS_HX_TGA_TBL_SYNC]   
AS  
BEGIN  
  
 DECLARE @DocumentId INT  
 DECLARE @DDOCNAME Varchar(400)  
   
 DECLARE @docHandle int;    
 DECLARE @xmlDocument nvarchar(max); -- or xml type    
   
 DECLARE @StrRaiseError VARCHAR(100);  
  
 DECLARE @RECCNT  INT  
 DECLARE @EMPLID Varchar(11)  
  
 DECLARE @DID INT, @EFFDT DATETIME, @AUDIT_STAMP DATETIME, @STATUS VARCHAR(20)  
   
-- PART A - XML Sync to Staging Table  
   
  
 DECLARE @tblxml TABLE    
 (    
   U_ID INT IDENTITY(1,1)     
  , DID BIGINT    
  , ENTITYNAME VARCHAR(50)    
  , EXTRACT_XML nvarchar(max)    
  , DDOCNAME VARCHAR(50)    
  )   
  DECLARE @TotalFiles INT   
     
  SELECT @TotalFiles = COUNT(1) FROM ORA_HX_TGA_TBL_XML_SYNC WHERE PROCESS_FLAG = 0    
  INSERT INTO @tblxml (DID, ENTITYNAME, EXTRACT_XML, DDOCNAME)     
  SELECT   DISTINCT  
   DID, ENTITYNAME, EXTRACT_XML, DDOCNAME FROM ORA_HX_TGA_TBL_XML_SYNC     
  WHERE     
   PROCESS_FLAG = 0    
   AND DID NOT IN (SELECT DID FROM PS_HX_TGA_TBL_STG)    
  DECLARE @i INT=1     
       
 SET @StrRaiseError= 'Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_files to be procssed: ' + RTRIM(CAST(@TotalFiles AS varchar(10)));  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  WHILE @i <= @TotalFiles  --Main Loop  
  BEGIN   
   --SET @DDOCNAME=(SELECT DDOCNAME from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)  
   --SET @DID= (SELECT DID from ##PS_HX_EMPL_TSR_SYNC_A WHERE TABLEID=@i)  
     
   SET @StrRaiseError= 'Processing file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
        
    SELECT @XmlDocument = EXTRACT_XML  
    , @DDOCNAME = DDOCNAME  
    , @DID = DID   
    from @tblxml WHERE U_ID = @i   
   EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDocument;   
     
   SET @StrRaiseError= 'Xml prepare and parsing process completed for the file ... '+ @DDOCNAME  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   IF @XmlDocument <>''   
      
    SET @StrRaiseError= 'Xml to Staging table for the file ... '+ @DDOCNAME  
    RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
--TRUNCATE TABLE PS_HX_TGA_TBL_STG  
    BEGIN   
     INSERT INTO PS_HX_TGA_TBL_STG (  
       --TRN_ID,  
       EMPLID  
       ,DEPTID  
       ,EFFDT  
       ,HX_PRIOR_LOCATION  
       ,LOCATION  
       ,BEGIN_DT  
       ,END_DT  
       ,AUDIT_ACTN  
       ,AUDIT_STAMP  
       ,PROCESS_DATE  
       ,STATUS  
       ,TRAVEL_TYPE  
       ,OPERATOR  
       ,TRN_TGA_ID  
       ,HX_POSTING_DT  
       ,PROCESS_FLAG  
       ,DID  
       )  
       SELECT  -- Action_Code,  
         P.Person_Number    
         ,Department_Name  
         ,Effective_Start_Date   
         ,''  
         ,LEGISLATION_CODE  
         ,Effective_Start_Date  
         ,Effective_End_Date   
         ,''  
         ,Last_Update_Date  
         ,NULL AS PROCESS_DATE  
         ,''   
         ,''  
         ,''  
         ,''  
         ,''  
         ,'N',@DID  
       FROM OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PS_HX_TGA_TBL/Person_DG/LocationDetails/Location_DG/Location_Record', 2) WITH (  
            
         Effective_Start_Date DATETIME  
         ,Effective_End_Date DATETIME  
         ,Department_Name NVARCHAR(100)  
         ,Assignment_Number NVARCHAR(50)  
         ,Last_Update_Date DATETIME           
         ,Person_ID NVARCHAR(20)  
         ,Person_Number NVARCHAR(30)  
         ,LEGISLATION_CODE NVARCHAR(20)  
         ,Action_Code NVARCHAR(50)  
         ,Creation_Date DATETIME  
         )C    
         JOIN     
         (  
         (SELECT     
          Person_ID , Person_Number    
         FROM     
          OPENXML(@docHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_PS_HX_TGA_TBL/Person_DG/PersonDetails',2)    
          WITH     
          (      
           Person_ID NVARCHAR(100),      
           Person_Number NVARCHAR(200)  
          )     
         )) P ON P.Person_ID=C.Person_ID AND P.Person_Number = C.Person_Number   
      
      END   
        
      SET @StrRaiseError= 'Xml to Staging table process completed for the file ... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
      SET @StrRaiseError= 'Transform Process start... '+ @DDOCNAME  
      RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   --- TRANSFORM LOGIC START  
        
      UPDATE A   
       SET A.EMPLID=RIGHT(EMPLID,5)  
      FROM PS_HX_TGA_TBL_STG A  
       WHERE A.PROCESS_FLAG='N' AND DID=@DID  
       
	   UPDATE A
	   SET A.DEPTID=B.DEPTID
	   FROM PS_HX_TGA_TBL_STG A  ,PS_DEPT_TBL B
       WHERE A.DEPTID=B.DESCR
	   AND A.PROCESS_FLAG='N' AND DID=@DID 
       
  
     SET @StrRaiseError= 'Transform Process End... '+ @DDOCNAME  
     RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
       
   --TRANSFORM LOGIC END  
  
  SET @StrRaiseError= 'update XML SYNC file and start picking next XML file.'   
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   UPDATE ORA_HX_TGA_TBL_XML_SYNC SET PROCESS_FLAG=1 ,PROCESSED_DATE=getdate() where DDOCNAME=@DDOCNAME   
    
     
    
  SET @i=@i+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete gloabl temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
   
 --SELECT * FROM PS_HX_TGA_TBL_STG  
  
 SET @StrRaiseError= 'PartA-XML Sync to Staging Table Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
   
 -----------   
  
-- PART B - Staging Table to PeopleSoft Table  
  
 if object_id('tempdb..##PS_HX_TGA_TBL_SYNC_B') is not null  
 begin  
  drop table ##PS_HX_TGA_TBL_SYNC_B  
 end  
   
 --CREATE TABLE ##PERSON_SYNC_B -- Declaring a temporary table  
 -- (    
 --  TABLEID DECIMAL,  
 --   EMPLID NVARCHAR(11),  
 --   PER_STATUS VARCHAR(1),  
 --   BIRTHPLACE VARCHAR(30),  
 --   BIRTHCOUNTRY VARCHAR(3),  
 --   BIRTHSTATE VARCHAR(60),  
 --   DT_OF_DEATH DATE,  
 --   ORIG_HIRE_DT DATE,  
 --   HIGHLY_COMP_EMPL_P VARCHAR(2),  
 --   HIGHLY_COMP_EMPL_C VARCHAR(2),  
 --   HX_IT_EXP DECIMAL,  
 --   HX_YRS_OF_EXP DECIMAL,  
 --   LAST_CHILD_UPDDTM DATE,  
 --   BIRTHDATE DATE,  
 --   PROCESS_FLAG VARCHAR(1),DID INT  
 -- )  
   
  --INSERT INTO ##PERSON_SYNC_B SELECT ROW_NUMBER() OVER(ORDER BY EMPLID)  
  -- ,EMPLID,PER_STATUS, BIRTHPLACE, BIRTHCOUNTRY,BIRTHSTATE,DT_OF_DEATH  
  -- ,ORIG_HIRE_DT,'N','',HX_IT_EXP,HX_YRS_OF_EXP,LAST_CHILD_UPDDTM,BIRTHDATE  
  -- ,'N' ,DID  
  -- FROM PS_HX_TGA_TBL_STG WHERE PROCESS_FLAG='N'  
     
  
   select EMPLID  
   ,DEPTID  
   ,EFFDT  
   ,HX_PRIOR_LOCATION  
   ,LOCATION  
   ,BEGIN_DT  
   ,END_DT  
   ,AUDIT_ACTN  
   ,AUDIT_STAMP  
   ,PROCESS_DATE  
   ,STATUS  
   ,TRAVEL_TYPE  
   ,OPERATOR  
   ,TRN_TGA_ID  
   ,HX_POSTING_DT  
   ,LASTUPDDTTM  
   ,LASTUPDOPRID  
   ,PROCESS_FLAG  
   ,DID   
   into ##PS_HX_TGA_TBL_SYNC_B from PS_HX_TGA_TBL_STG where 1=2  
    
  ALTER TABLE ##PS_HX_TGA_TBL_SYNC_B ADD TABLEID INT  
  
    
  
   INSERT INTO ##PS_HX_TGA_TBL_SYNC_B  
    SELECT EMPLID  
     ,DEPTID  
     ,EFFDT  
     ,HX_PRIOR_LOCATION  
     ,LOCATION  
     ,BEGIN_DT  
     ,END_DT  
     ,AUDIT_ACTN  
     ,AUDIT_STAMP  
     ,PROCESS_DATE  
     ,STATUS  
     ,TRAVEL_TYPE  
     ,OPERATOR  
     ,TRN_TGA_ID  
     ,HX_POSTING_DT  
     ,LASTUPDDTTM  
     ,LASTUPDOPRID  
     ,PROCESS_FLAG  
     ,DID  
     ,ROW_NUMBER() OVER(ORDER BY EMPLID) FROM PS_HX_TGA_TBL_STG WHERE PROCESS_FLAG='N'  
     
  DECLARE @TotalRecs INT=(SELECT COUNT(1)FROM ##PS_HX_TGA_TBL_SYNC_B )  
  DECLARE @j INT=1  
    
  SET @StrRaiseError= 'PartA-Staging Table to PeopleSoft Table:Process Start on '+ CONVERT(VARCHAR(20),GETDATE(),121) + ':No_of_Recs to be procssed: '   
       + RTRIM(CAST(@TotalRecs AS varchar(10)));  
  RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  SET @DID=0  
   
 WHILE @j<=@TotalRecs  --Main Loop  
  BEGIN   
   SET @EMPLID=(SELECT EMPLID from ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j)  
   SET @DID=(SELECT DID FROM ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j)  
   SET @EFFDT=(SELECT EFFDT FROM ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j)  
   SET @AUDIT_STAMP=(SELECT AUDIT_STAMP FROM ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j)  
   SET @STATUS=(SELECT STATUS FROM ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j)  
     
   SET @StrRaiseError= 'Processing-Employee ID ... '+ @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
     
   SET @RECCNT=(SELECT COUNT(1) FROM PS_HX_TGA_TBL WHERE EMPLID=@EMPLID  
     AND CONVERT(DATE,EFFDT) = CONVERT(DATE,@EFFDT)  
     AND CONVERT(DATE,AUDIT_STAMP) = CONVERT(DATE,@AUDIT_STAMP)  
     AND STATUS=@STATUS)  
  
   IF @RECCNT=0   
    BEGIN   
    print '-------1-----------'  
     INSERT INTO PS_HX_TGA_TBL (--TRN_ID,  
            EMPLID  
            ,DEPTID  
            ,EFFDT  
            ,HX_PRIOR_LOCATION  
            ,LOCATION  
            ,BEGIN_DT  
            ,END_DT  
            ,AUDIT_ACTN  
            ,AUDIT_STAMP  
            ,PROCESS_DATE  
            ,STATUS  
            ,TRAVEL_TYPE  
            ,OPERATOR  
            ,TRN_TGA_ID  
            ,HX_POSTING_DT)  
     SELECT   --TRN_ID,  
       EMPLID  
       ,DEPTID  
       ,EFFDT  
       ,HX_PRIOR_LOCATION  
       ,LOCATION  
       ,BEGIN_DT  
       ,END_DT  
       ,AUDIT_ACTN  
       ,AUDIT_STAMP  
       ,PROCESS_DATE  
       ,STATUS  
       ,TRAVEL_TYPE  
       ,OPERATOR  
       ,TRN_TGA_ID  
       ,HX_POSTING_DT  
     FROM ##PS_HX_TGA_TBL_SYNC_B WHERE TABLEID=@j AND EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    END  
   ELSE  
    BEGIN   
    print '-------2-----------'  
      
     UPDATE A   
      SET   
      A.DEPTID    = ISNULL(B.DEPTID    ,'')  
      ,A.EFFDT     = ISNULL(B.EFFDT     ,'')  
      ,A.HX_PRIOR_LOCATION  = ISNULL(B.HX_PRIOR_LOCATION  ,'')  
      ,A.LOCATION    = ISNULL(B.LOCATION    ,'')  
      ,A.BEGIN_DT    = ISNULL(B.BEGIN_DT    ,'')  
      ,A.END_DT    = ISNULL(B.END_DT    ,'')  
      ,A.AUDIT_ACTN   = ISNULL(B.AUDIT_ACTN   ,'')  
      ,A.AUDIT_STAMP   = ISNULL(B.AUDIT_STAMP   ,'')  
      ,A.PROCESS_DATE   = ISNULL(B.PROCESS_DATE   ,'')  
      ,A.STATUS    = ISNULL(B.STATUS    ,'')  
      ,A.TRAVEL_TYPE   = ISNULL(B.TRAVEL_TYPE   ,'')  
      ,A.OPERATOR    = ISNULL(B.OPERATOR    ,'')  
      ,A.TRN_TGA_ID   = ISNULL(B.TRN_TGA_ID   ,'')  
      ,A.HX_POSTING_DT   = ISNULL(B.HX_POSTING_DT   ,'')  
     FROM PS_HX_TGA_TBL A,##PS_HX_TGA_TBL_SYNC_B B  
     WHERE A.EMPLID =B.EMPLID COLLATE SQL_Latin1_General_CP1_CI_AS   
     AND CONVERT(DATE,A.EFFDT) = CONVERT(DATE,B.EFFDT)  
     AND CONVERT(DATE,A.AUDIT_STAMP) = CONVERT(DATE,B.AUDIT_STAMP)  
     AND A.STATUS=B.STATUS  
     AND A.EMPLID=@EMPLID AND B.TABLEID=@j AND B.PROCESS_FLAG='N' AND DID=@DID  
    END   
       
   --TRANSFORM LOGIC END  
  
   SET @StrRaiseError= 'updating staging table .'  + @EMPLID  
   RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
   UPDATE  PS_HX_TGA_TBL_STG SET PROCESS_FLAG='Y',LASTUPDDTTM=GETDATE()  where EMPLID=@EMPLID AND PROCESS_FLAG='N' AND DID=@DID  
    
  SET @j=@j+1  
  
 END -- While loop ends here  
   
 SET @StrRaiseError= 'delete the global temp table... '  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
    
  DROP TABLE ##PS_HX_TGA_TBL_SYNC_B  
 --SELECT * FROM PS_HX_TGA_TBL  
  
 SET @StrRaiseError= 'Process End on'+ CONVERT(VARCHAR(20),GETDATE(),121);  
 RAISERROR (@StrRaiseError, 10, 1) WITH NOWAIT  
  
  -----------  */  
   
END   
  
  
  