DECLARE @XmlDocumentHandle int  
DECLARE @XmlDocument nvarchar(max)  
SET @XmlDocument = N'<?xml version="1.0" encoding="UTF-16" ?> <DATA_DS><G_1><PAYROLL_ACTION_ID>27678</PAYROLL_ACTION_ID><G_2><FILE_FRAGMENT><HEX_ADDRESS_EXTRACT><REP_CATEGORY_NAME>HEX_ADDRESS_EXTRACT</REP_CATEGORY_NAME><parameters><request_id>300000208993709</request_id><FLOW_NAME>AddressFlow</FLOW_NAME><legislative_data_group_id/><effective_date>2022-03-31</effective_date><start_date/><report_category_id>300000201052275</report_category_id><action_parameter_group_id/><changes_only>Y</changes_only></parameters><Employee_DG><OBJECT_ACTION_ID>3020909</OBJECT_ACTION_ID><Employee_ER><Person_ID>300000027515769</Person_ID><Person_Number>1000047014</Person_Number><Address_DG><Address_ER><Address_ID>300000189068814</Address_ID><Address_Type>MAIL</Address_Type><Effective_Start_Date>2019-05-20T00:00:00.000Z</Effective_Start_Date><Effective_End_Date>4712-12-31T00:00:00.000Z</Effective_End_Date><Address_Line1>47014May 20 2019 12:00AMtest</Address_Line1><Address_Line2>CCCCCC</Address_Line2><Address_Line3>DDDDDD</Address_Line3><Address_Line4>AAAAA</Address_Line4><Town_or_City>Bangalore</Town_or_City><Country>IN</Country><Address_Additional_Attribute1/><Address_Additional_Attribute2/><Address_Additional_Attribute3/><Region1>IN</Region1><Region2>Karnataka</Region2><Region3/><Postal_Code>560037</Postal_Code><Last_Update_Date>2022-03-31T13:35:24.000Z</Last_Update_Date><Last_Updated_By>kalpanab@hexaware.com</Last_Updated_By><Person_Number>1000047014</Person_Number></Address_ER></Address_DG><Address_DG><Address_ER><Address_ID>300000027515786</Address_ID><Address_Type>HOME</Address_Type><Effective_Start_Date>2019-05-20T00:00:00.000Z</Effective_Start_Date><Effective_End_Date>4712-12-31T00:00:00.000Z</Effective_End_Date><Address_Line1>AAAAAA</Address_Line1><Address_Line2>AAAAA</Address_Line2><Address_Line3>AAAAAA</Address_Line3><Address_Line4>AAAAA</Address_Line4><Town_or_City>AAAAA</Town_or_City><Country>IN</Country><Address_Additional_Attribute1/><Address_Additional_Attribute2/><Address_Additional_Attribute3/><Region1/><Region2/><Region3/><Postal_Code>600056</Postal_Code><Last_Update_Date>2022-02-17T13:59:19.000Z</Last_Update_Date><Last_Updated_By>FUSION_APPS_HCM_ESS_LOADER_APPID</Last_Updated_By><Person_Number>1000047014</Person_Number></Address_ER></Address_DG></Employee_ER></Employee_DG></HEX_ADDRESS_EXTRACT></FILE_FRAGMENT></G_2></G_1></DATA_DS>'  
-- Create an internal representation of the XML document.  
EXEC sp_xml_preparedocument @XmlDocumentHandle OUTPUT, @XmlDocument  
-- Execute a SELECT statement using OPENXML rowset provider.  
SELECT    *  
FROM      OPENXML (@XmlDocumentHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/HEX_ADDRESS_EXTRACT/Employee_DG/Employee_ER/Address_DG/Address_ER',2)  
           WITH ( 
		         Person_Number varchar(100) '../../Person_Number',
				 Person_ID varchar(100) '../../Person_ID',
		         Address_ID  nvarchar(100),  
                 Address_Type nvarchar(200),
				 Effective_Start_Date DATETIME,
				 Effective_End_Date DATETIME,
				 Address_Line1  nvarchar(100),
				 Address_Line2  nvarchar(100),
				 Address_Line3  nvarchar(100),
				 Address_Line4  nvarchar(100),
				 Town_or_City  nvarchar(100),
				 Country  nvarchar(100),	
				 Address_Additional_Attribute1  nvarchar(100),	
				 Address_Additional_Attribute2  nvarchar(100),	
				 Address_Additional_Attribute3  nvarchar(100),	
				 Region1  nvarchar(100),	
				 Region2  nvarchar(100),	
				 Region3  nvarchar(100),	
				 Postal_Code  nvarchar(100),	
				 Last_Update_Date  nvarchar(100),	
				 Last_Updated_By  nvarchar(100)


				 )
EXEC sp_xml_removedocument @XmlDocumentHandle

