USE HCM92DEV
GO

--N'<?xml version="1.0" encoding="UTF-16" ?> <DATA_DS><G_1><PAYROLL_ACTION_ID>28041
--</PAYROLL_ACTION_ID><G_2><FILE_FRAGMENT><Employee_Details><REP_CATEGORY_NAME>HEX_PERSON_EXTRACT</REP_CATEGORY_NAME>
--<parameters><request_id>300000209090887</request_id><FLOW_NAME>PersonTesting</FLOW_NAME><legislative_data_group_id/><effective_date>2022-04-01</effective_date>
--<start_date/><report_category_id>300000201309338</report_category_id><action_parameter_group_id/><changes_only>Y</changes_only>
--</parameters><Person><OBJECT_ACTION_ID>3304015</OBJECT_ACTION_ID><Person_Details><Person_ID>300000189563086</Person_ID>
--<Person_Number>1000037288</Person_Number><Last_Update_Date>2022-03-17</Last_Update_Date><Person_Date_of_Birth>1900-01-01</Person_Date_of_Birth>
--<Person_Date_of_Death/><Person_Country_of_Birth>AF</Person_Country_of_Birth><Person_Region_of_Birth/><Person_Town_of_Birth/>
--<Effective_Start_Date>2017-04-03</Effective_Start_Date><Employee_Status>ACTIVE</Employee_Status>
--</Person_Details></Person></Employee_Details></FILE_FRAGMENT></G_2></G_1></DATA_DS>'  

--SELECT * INTO PS_PERSON_STG_SSIS FROM PS_PERSON_STG


/*
DECLARE @XmlDocument nvarchar(max)  
SELECT @XmlDocument = Extract_Xml FROM ORA_PERSON_XML_SYNC where EntityName='PS_PERSON'
EXEC USP_ORACLE_TO_HRMS_PS_PERSON @XmlDocument


*/

ALTER PROC USP_ORACLE_TO_HRMS_PS_PERSON
@XmlDocument nvarchar(max)  
AS
BEGIN
DECLARE @XmlDocumentHandle int 

SELECT @XmlDocument = Extract_Xml FROM ORA_PERSON_XML_SYNC where EntityName='PS_PERSON' and Process_Flag=0

TRUNCATE TABLE PS_PERSON_STG

-- Create an internal representation of the XML document.  
EXEC sp_xml_preparedocument @XmlDocumentHandle OUTPUT, @XmlDocument  
-- Execute a SELECT statement using OPENXML rowset provider.  

--SELECT top 1 * FROM PS_PERSON_STG
INSERT INTO PS_PERSON_STG(
EMPLID
,BIRTHPLACE
,BIRTHCOUNTRY
,BIRTHSTATE
,DT_OF_DEATH
,ORIG_HIRE_DT
,LAST_CHILD_UPDDTM
,BIRTHDATE
)
SELECT   Person_Number
,Person_Town_of_Birth
,Person_Country_of_Birth
,Person_Region_of_Birth
,Person_Date_of_Death
,Effective_Start_Date
,Last_Update_Date
,Person_Date_of_Birth
FROM      OPENXML (@XmlDocumentHandle, '/DATA_DS/G_1/G_2/FILE_FRAGMENT/Employee_Details/Person/Person_Details',2)  
           WITH (Person_ID  nvarchar(100),  
                 Person_Number nvarchar(200),
				 Last_Update_Date DATETIME,
				 Person_Date_of_Birth DATETIME,
				 Person_Date_of_Death DATETIME,
				 Person_Country_of_Birth NVARCHAR(100),
				 Person_Region_of_Birth NVARCHAR(100),
				 Person_Town_of_Birth NVARCHAR(100),
				 Effective_Start_Date NVARCHAR(100))	
				 --Employee_Status NVARCHAR(100),
				 --ACTIVE NVARCHAR(100))
EXEC sp_xml_removedocument @XmlDocumentHandle

END