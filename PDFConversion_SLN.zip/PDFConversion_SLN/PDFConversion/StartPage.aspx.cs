﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Spire.Doc;
using Spire.Doc.Documents;
using Adobe.DocumentServices.PDFTools;
using Adobe.DocumentServices.PDFTools.auth; 
using Adobe.DocumentServices.PDFTools.pdfops; 
using Adobe.DocumentServices.PDFTools.io; 
using Adobe.DocumentServices.PDFTools.exception;
using System.IO;


namespace PDFConversion
{
    public partial class StartPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void btnConvert_Click(object sender, EventArgs e)
        {
            //PdfDocument documemt = new PdfDocument();
            //documemt.LoadFromFile(@"D:\\SibeeshPassion.pdf");
            //Image image = documemt.SaveAsImage(0, PdfImageType.Bitmap, 400, 400);
            //image.Save(@"D:\\result.jpg");
            //documemt.Close();
            //Load Document
            
            Document doc = new Document();
            //Pass path of Word Document in LoadFromFile method  
            doc.LoadFromFile(@"D:\21736\CR\O2C\POC\PDFConversion\InvoiceTemplate.Docx");
            //Pass Document Name and FileFormat of Document as Parameter in SaveToFile Method  
            doc.SaveToFile(@"D:\21736\CR\O2C\POC\PDFConversion\Convert.PDF", FileFormat.PDF);
            //Launch Document  
            System.Diagnostics.Process.Start(@"D:\21736\CR\O2C\POC\PDFConversion\Convert.PDF");


        }
        protected void btnAdobe_Click(object sender, EventArgs e)
        {
            // Initial setup, create credentials instance. 
            Credentials credentials = Credentials.ServiceAccountCredentialsBuilder().FromFile(@"D:\21736\CR\O2C\POC\PDFConversion\PDFConversion\PDFConversion\App_Data\pdftools-api-credentials.json").Build();

            ExecutionContext executionContext = ExecutionContext.Create(credentials);
            CreatePDFOperation createPdfOperation = CreatePDFOperation.CreateNew();
            // Set operation input from a source file. 
            FileRef source = FileRef.CreateFromLocalFile(@"D:\21736\CR\O2C\POC\PDFConversion\InvoiceTemplate.Docx");
            createPdfOperation.SetInput(source);
            // Execute the operation. 
            FileRef result = createPdfOperation.Execute(executionContext);
            
            // Save the result to the specified location. 
            result.SaveAs(@"D:\21736\CR\O2C\POC\PDFConversion\InvoiceTemplateOutput.pdf");


        }
    }
}